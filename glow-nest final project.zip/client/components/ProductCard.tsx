import React from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Heart, Star, ShoppingBag } from 'lucide-react';
import { Product } from '@/data/products';

interface ProductCardProps {
  product: Product;
  showAddToCart?: boolean;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, showAddToCart = true }) => {
  return (
    <Card className="group cursor-pointer bg-white hover:shadow-xl transition-all duration-300 hover:-translate-y-1 border-kylie-pink-light/20">
      <CardContent className="p-0">
        <div className="relative">
          <Link to={`/product/${product.id}`}>
            <div className="aspect-square relative overflow-hidden rounded-t-lg">
              <img 
                src={product.image} 
                alt={product.name}
                className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors duration-300" />
            </div>
          </Link>
          
          {/* Badge */}
          {product.badge && (
            <Badge className={`absolute top-3 left-3 text-white text-xs font-medium ${
              product.badge === 'NEW' ? 'bg-kylie-coral' :
              product.badge === 'BESTSELLER' ? 'bg-kylie-pink' :
              product.badge === 'LIMITED' ? 'bg-kylie-brown' :
              product.badge === 'SALE' ? 'bg-red-500' :
              'bg-kylie-pink-dark'
            }`}>
              {product.badge}
            </Badge>
          )}
          
          {/* Wishlist Button */}
          <Button 
            variant="ghost" 
            size="sm" 
            className="absolute top-3 right-3 bg-white/80 hover:bg-white opacity-0 group-hover:opacity-100 transition-opacity duration-300"
          >
            <Heart className="h-4 w-4" />
          </Button>
          
          {/* Stock Status */}
          {!product.inStock && (
            <div className="absolute inset-0 bg-black/50 flex items-center justify-center rounded-t-lg">
              <span className="text-white font-semibold">Out of Stock</span>
            </div>
          )}
        </div>
        
        <div className="p-4 space-y-3">
          <Link to={`/product/${product.id}`}>
            <h3 className="font-semibold text-foreground group-hover:text-kylie-pink transition-colors line-clamp-2">
              {product.name}
            </h3>
          </Link>
          
          {/* Rating */}
          <div className="flex items-center space-x-2">
            <div className="flex space-x-1">
              {[1, 2, 3, 4, 5].map((star) => (
                <Star 
                  key={star} 
                  className={`h-3 w-3 ${
                    star <= Math.floor(product.rating) 
                      ? 'fill-kylie-coral text-kylie-coral' 
                      : 'text-gray-300'
                  }`} 
                />
              ))}
            </div>
            <span className="text-xs text-muted-foreground">
              {product.rating} ({product.reviews})
            </span>
          </div>
          
          {/* Tags */}
          {product.tags && product.tags.length > 0 && (
            <div className="flex flex-wrap gap-1">
              {product.tags.slice(0, 2).map((tag) => (
                <Badge key={tag} variant="secondary" className="text-xs bg-kylie-pink-light/20 text-kylie-pink-dark border-0">
                  {tag}
                </Badge>
              ))}
            </div>
          )}
          
          {/* Price and Actions */}
          <div className="flex items-center justify-between pt-2">
            <div className="flex items-center space-x-2">
              <span className="text-lg font-bold text-kylie-pink">${product.price}</span>
              {product.originalPrice && (
                <span className="text-sm text-muted-foreground line-through">
                  ${product.originalPrice}
                </span>
              )}
            </div>
            
            {showAddToCart && product.inStock && (
              <Button 
                size="sm" 
                className="bg-kylie-pink hover:bg-kylie-pink-dark text-white opacity-0 group-hover:opacity-100 transition-all duration-300"
              >
                <ShoppingBag className="h-3 w-3 mr-1" />
                Add
              </Button>
            )}
          </div>
          
          {/* Shades indicator */}
          {product.shades && product.shades.length > 1 && (
            <div className="flex items-center space-x-2 pt-1">
              <span className="text-xs text-muted-foreground">
                {product.shades.length} shades available
              </span>
              <div className="flex space-x-1">
                {product.shades.slice(0, 4).map((shade, index) => (
                  <div 
                    key={shade}
                    className={`w-3 h-3 rounded-full border border-gray-200 ${
                      index === 0 ? 'bg-kylie-pink' :
                      index === 1 ? 'bg-kylie-coral' :
                      index === 2 ? 'bg-kylie-nude' :
                      'bg-kylie-brown'
                    }`}
                  />
                ))}
                {product.shades.length > 4 && (
                  <span className="text-xs text-muted-foreground">+{product.shades.length - 4}</span>
                )}
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default ProductCard;
