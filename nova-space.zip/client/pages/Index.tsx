import { AnnouncementBar } from '@/components/AnnouncementBar';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { Hero } from '@/components/sections/Hero';
import { Lipsticks } from '@/components/sections/Lipsticks';
import { Skincare } from '@/components/sections/Skincare';
import { Accessories } from '@/components/sections/Accessories';
import { Sale } from '@/components/sections/Sale';
import { About } from '@/components/sections/About';

export default function Index() {
  return (
    <div className="min-h-screen bg-white">
      <AnnouncementBar />
      <Header />
      
      <main>
        <Hero />
        <Lipsticks />
        <Skincare />
        <Accessories />
        <Sale />
        <About />
      </main>

      <Footer />
    </div>
  );
}
