import { AnnouncementBar } from '@/components/AnnouncementBar';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';

export default function ProductListPage() {
  return (
    <div className="min-h-screen bg-white">
      <AnnouncementBar />
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">All Products</h1>
          <p className="text-lg text-gray-600 mb-8">
            This is a placeholder page. Continue prompting to fill in the product listing content.
          </p>
          <div className="bg-rose-50 border border-rose-200 rounded-lg p-8">
            <p className="text-rose-800">Product grid will be implemented here</p>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
