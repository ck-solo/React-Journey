import { Button } from '@/components/ui/button';

export function About() {
  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              Our Beauty Story
            </h2>
            <p className="text-lg text-gray-600 mb-6">
              Founded with a passion for enhancing natural beauty, our brand is dedicated to creating 
              high-quality, innovative products that empower individuals to express their unique style.
            </p>
            <p className="text-lg text-gray-600 mb-8">
              From carefully curated ingredients to sustainable packaging, every detail reflects our 
              commitment to excellence and environmental responsibility.
            </p>
            
            <div className="grid grid-cols-2 gap-6 mb-8">
              <div className="text-center">
                <div className="text-3xl font-bold text-rose-600 mb-2">1M+</div>
                <p className="text-gray-600">Happy Customers</p>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-rose-600 mb-2">100+</div>
                <p className="text-gray-600">Premium Products</p>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-rose-600 mb-2">5★</div>
                <p className="text-gray-600">Average Rating</p>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-rose-600 mb-2">24/7</div>
                <p className="text-gray-600">Customer Support</p>
              </div>
            </div>

            <Button 
              size="lg" 
              className="bg-rose-600 hover:bg-rose-700 text-white px-8"
            >
              Learn More About Us
            </Button>
          </div>

          <div className="relative">
            <div className="aspect-square bg-gradient-to-br from-rose-100 via-peach-100 to-nude-100 rounded-2xl p-8 flex items-center justify-center">
              <div className="text-center">
                <div className="text-6xl mb-4">✨</div>
                <h3 className="text-2xl font-semibold text-gray-900 mb-2">Premium Quality</h3>
                <p className="text-gray-600">Crafted with care and precision</p>
              </div>
            </div>
            
            {/* Floating elements */}
            <div className="absolute -top-4 -right-4 w-20 h-20 bg-rose-200 rounded-full flex items-center justify-center text-2xl">
              💄
            </div>
            <div className="absolute -bottom-4 -left-4 w-16 h-16 bg-peach-200 rounded-full flex items-center justify-center text-xl">
              🧴
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
