import { useState } from 'react';
import { ProductGrid } from '@/components/ProductGrid';
import { Button } from '@/components/ui/button';

const hydratingProducts = [
  { id: '10', name: 'Hydra Boost Serum', price: '$45', image: '🧴', category: 'hydrating' },
  { id: '11', name: 'Moisture Lock Cream', price: '$52', image: '🫧', category: 'hydrating' },
  { id: '12', name: 'Dewy Essence', price: '$38', image: '💧', category: 'hydrating' },
];

const antiAgingProducts = [
  { id: '13', name: 'Retinol Night Renewal', price: '$65', image: '🌙', category: 'anti-aging' },
  { id: '14', name: 'Collagen Booster', price: '$58', image: '✨', category: 'anti-aging' },
  { id: '15', name: 'Vitamin C Brightener', price: '$42', image: '🍊', category: 'anti-aging' },
];

const cleanserProducts = [
  { id: '16', name: 'Gentle Foam Cleanser', price: '$28', image: '���', category: 'cleansers' },
  { id: '17', name: 'Micellar Water', price: '$24', image: '💫', category: 'cleansers' },
  { id: '18', name: 'Exfoliating Scrub', price: '$32', image: '🧽', category: 'cleansers' },
];

export function Skincare() {
  const [activeTab, setActiveTab] = useState('hydrating');

  const scrollToSubsection = (subsection: string) => {
    setActiveTab(subsection);
    const element = document.getElementById(`skincare-${subsection}`);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const getProducts = () => {
    switch (activeTab) {
      case 'anti-aging': return antiAgingProducts;
      case 'cleansers': return cleanserProducts;
      default: return hydratingProducts;
    }
  };

  const getTitle = () => {
    switch (activeTab) {
      case 'anti-aging': return 'Anti-Aging';
      case 'cleansers': return 'Cleansers';
      default: return 'Hydrating';
    }
  };

  return (
    <section id="skincare" className="py-20 bg-gradient-to-b from-peach-25 to-nude-25">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Skincare Essentials
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Nourish your skin with our scientifically-formulated skincare collection
          </p>
        </div>

        {/* Sub-navigation */}
        <div className="flex justify-center mb-12">
          <div className="flex flex-wrap gap-4 bg-white rounded-full p-2 shadow-lg">
            <Button
              variant={activeTab === 'hydrating' ? 'default' : 'ghost'}
              className={`rounded-full px-6 ${
                activeTab === 'hydrating' 
                  ? 'bg-peach-500 text-white' 
                  : 'text-gray-600 hover:text-peach-500'
              }`}
              onClick={() => scrollToSubsection('hydrating')}
            >
              Hydrating
            </Button>
            <Button
              variant={activeTab === 'anti-aging' ? 'default' : 'ghost'}
              className={`rounded-full px-6 ${
                activeTab === 'anti-aging' 
                  ? 'bg-peach-500 text-white' 
                  : 'text-gray-600 hover:text-peach-500'
              }`}
              onClick={() => scrollToSubsection('anti-aging')}
            >
              Anti-Aging
            </Button>
            <Button
              variant={activeTab === 'cleansers' ? 'default' : 'ghost'}
              className={`rounded-full px-6 ${
                activeTab === 'cleansers' 
                  ? 'bg-peach-500 text-white' 
                  : 'text-gray-600 hover:text-peach-500'
              }`}
              onClick={() => scrollToSubsection('cleansers')}
            >
              Cleansers
            </Button>
          </div>
        </div>

        {/* Product grids */}
        <div id="skincare-hydrating" className={activeTab === 'hydrating' ? 'block' : 'hidden'}>
          <ProductGrid products={hydratingProducts} title={getTitle()} />
        </div>
        
        <div id="skincare-anti-aging" className={activeTab === 'anti-aging' ? 'block' : 'hidden'}>
          <ProductGrid products={antiAgingProducts} title={getTitle()} />
        </div>
        
        <div id="skincare-cleansers" className={activeTab === 'cleansers' ? 'block' : 'hidden'}>
          <ProductGrid products={cleanserProducts} title={getTitle()} />
        </div>

        <div className="text-center mt-12">
          <Button 
            size="lg" 
            variant="outline"
            className="border-peach-500 text-peach-500 hover:bg-peach-50 px-8"
          >
            View All Skincare
          </Button>
        </div>
      </div>
    </section>
  );
}
