import { useState } from 'react';
import { ProductGrid } from '@/components/ProductGrid';
import { Button } from '@/components/ui/button';

const brushSetProducts = [
  { id: '19', name: 'Professional Brush Set', price: '$89', image: '🖌️', category: 'brushes' },
  { id: '20', name: 'Travel Brush Kit', price: '$45', image: '✨', category: 'brushes' },
  { id: '21', name: 'Foundation Brush', price: '$28', image: '🎨', category: 'brushes' },
];

const beautyBagProducts = [
  { id: '22', name: 'Velvet Makeup Bag', price: '$35', image: '👜', category: 'bags' },
  { id: '23', name: 'Travel Organizer', price: '$42', image: '🧳', category: 'bags' },
  { id: '24', name: 'Mini Clutch', price: '$25', image: '💼', category: 'bags' },
];

const toolProducts = [
  { id: '25', name: 'LED Lighted Mirror', price: '$65', image: '🪞', category: 'tools' },
  { id: '26', name: 'Makeup Sponges', price: '$18', image: '🧽', category: 'tools' },
  { id: '27', name: 'Eyelash Curler', price: '$22', image: '🦋', category: 'tools' },
];

export function Accessories() {
  const [activeTab, setActiveTab] = useState('brushes');

  const scrollToSubsection = (subsection: string) => {
    setActiveTab(subsection);
    const element = document.getElementById(`accessories-${subsection}`);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const getProducts = () => {
    switch (activeTab) {
      case 'bags': return beautyBagProducts;
      case 'tools': return toolProducts;
      default: return brushSetProducts;
    }
  };

  const getTitle = () => {
    switch (activeTab) {
      case 'bags': return 'Beauty Bags';
      case 'tools': return 'Tools';
      default: return 'Brush Sets';
    }
  };

  return (
    <section id="accessories" className="py-20 bg-gradient-to-b from-nude-25 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Beauty Accessories
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Complete your beauty routine with our curated selection of tools and accessories
          </p>
        </div>

        {/* Sub-navigation */}
        <div className="flex justify-center mb-12">
          <div className="flex flex-wrap gap-4 bg-white rounded-full p-2 shadow-lg">
            <Button
              variant={activeTab === 'brushes' ? 'default' : 'ghost'}
              className={`rounded-full px-6 ${
                activeTab === 'brushes' 
                  ? 'bg-nude-500 text-white' 
                  : 'text-gray-600 hover:text-nude-500'
              }`}
              onClick={() => scrollToSubsection('brushes')}
            >
              Brush Sets
            </Button>
            <Button
              variant={activeTab === 'bags' ? 'default' : 'ghost'}
              className={`rounded-full px-6 ${
                activeTab === 'bags' 
                  ? 'bg-nude-500 text-white' 
                  : 'text-gray-600 hover:text-nude-500'
              }`}
              onClick={() => scrollToSubsection('bags')}
            >
              Beauty Bags
            </Button>
            <Button
              variant={activeTab === 'tools' ? 'default' : 'ghost'}
              className={`rounded-full px-6 ${
                activeTab === 'tools' 
                  ? 'bg-nude-500 text-white' 
                  : 'text-gray-600 hover:text-nude-500'
              }`}
              onClick={() => scrollToSubsection('tools')}
            >
              Tools
            </Button>
          </div>
        </div>

        {/* Product grids */}
        <div id="accessories-brushes" className={activeTab === 'brushes' ? 'block' : 'hidden'}>
          <ProductGrid products={brushSetProducts} title={getTitle()} />
        </div>
        
        <div id="accessories-bags" className={activeTab === 'bags' ? 'block' : 'hidden'}>
          <ProductGrid products={beautyBagProducts} title={getTitle()} />
        </div>
        
        <div id="accessories-tools" className={activeTab === 'tools' ? 'block' : 'hidden'}>
          <ProductGrid products={toolProducts} title={getTitle()} />
        </div>

        <div className="text-center mt-12">
          <Button 
            size="lg" 
            variant="outline"
            className="border-nude-500 text-nude-500 hover:bg-nude-50 px-8"
          >
            View All Accessories
          </Button>
        </div>
      </div>
    </section>
  );
}
