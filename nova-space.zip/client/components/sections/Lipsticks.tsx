import { useState } from 'react';
import { ProductGrid } from '@/components/ProductGrid';
import { Button } from '@/components/ui/button';

const matteProducts = [
  { id: '1', name: 'Velvet Matte Rouge', price: '$28', image: '💋', category: 'matte' },
  { id: '2', name: 'Nude Perfection', price: '$26', image: '💄', category: 'matte' },
  { id: '3', name: 'Berry Bliss', price: '$30', image: '🖤', category: 'matte' },
];

const glossyProducts = [
  { id: '4', name: 'Crystal Clear Gloss', price: '$24', image: '✨', category: 'glossy' },
  { id: '5', name: 'Honey Shimmer', price: '$22', image: '🍯', category: 'glossy' },
  { id: '6', name: 'Rose Gold Gleam', price: '$26', image: '🌹', category: 'glossy' },
];

const limitedProducts = [
  { id: '7', name: 'Sunset Collection', price: '$35', image: '🌅', category: 'limited' },
  { id: '8', name: 'Midnight Magic', price: '$40', image: '🌙', category: 'limited' },
  { id: '9', name: 'Golden Hour', price: '$38', image: '🌟', category: 'limited' },
];

export function Lipsticks() {
  const [activeTab, setActiveTab] = useState('matte');

  const scrollToSubsection = (subsection: string) => {
    setActiveTab(subsection);
    const element = document.getElementById(`lipsticks-${subsection}`);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const getProducts = () => {
    switch (activeTab) {
      case 'glossy': return glossyProducts;
      case 'limited': return limitedProducts;
      default: return matteProducts;
    }
  };

  const getTitle = () => {
    switch (activeTab) {
      case 'glossy': return 'Glossy Lipsticks';
      case 'limited': return 'Limited Edition';
      default: return 'Matte Lipsticks';
    }
  };

  return (
    <section id="lipsticks" className="py-20 bg-gradient-to-b from-white to-rose-25">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Lipsticks Collection
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            From bold mattes to glossy shimmers, find your perfect lip companion
          </p>
        </div>

        {/* Sub-navigation */}
        <div className="flex justify-center mb-12">
          <div className="flex flex-wrap gap-4 bg-white rounded-full p-2 shadow-lg">
            <Button
              variant={activeTab === 'matte' ? 'default' : 'ghost'}
              className={`rounded-full px-6 ${
                activeTab === 'matte' 
                  ? 'bg-rose-600 text-white' 
                  : 'text-gray-600 hover:text-rose-600'
              }`}
              onClick={() => scrollToSubsection('matte')}
            >
              Matte Lipsticks
            </Button>
            <Button
              variant={activeTab === 'glossy' ? 'default' : 'ghost'}
              className={`rounded-full px-6 ${
                activeTab === 'glossy' 
                  ? 'bg-rose-600 text-white' 
                  : 'text-gray-600 hover:text-rose-600'
              }`}
              onClick={() => scrollToSubsection('glossy')}
            >
              Glossy Lipsticks
            </Button>
            <Button
              variant={activeTab === 'limited' ? 'default' : 'ghost'}
              className={`rounded-full px-6 ${
                activeTab === 'limited' 
                  ? 'bg-rose-600 text-white' 
                  : 'text-gray-600 hover:text-rose-600'
              }`}
              onClick={() => scrollToSubsection('limited')}
            >
              Limited Edition
            </Button>
          </div>
        </div>

        {/* Product grids */}
        <div id="lipsticks-matte" className={activeTab === 'matte' ? 'block' : 'hidden'}>
          <ProductGrid products={matteProducts} title={getTitle()} />
        </div>
        
        <div id="lipsticks-glossy" className={activeTab === 'glossy' ? 'block' : 'hidden'}>
          <ProductGrid products={glossyProducts} title={getTitle()} />
        </div>
        
        <div id="lipsticks-limited" className={activeTab === 'limited' ? 'block' : 'hidden'}>
          <ProductGrid products={limitedProducts} title={getTitle()} />
        </div>

        <div className="text-center mt-12">
          <Button 
            size="lg" 
            variant="outline"
            className="border-rose-600 text-rose-600 hover:bg-rose-50 px-8"
          >
            View All Lipsticks
          </Button>
        </div>
      </div>
    </section>
  );
}
