import { Button } from '@/components/ui/button';

export function Sale() {
  return (
    <section id="sale" className="py-20 bg-gradient-to-r from-rose-600 to-peach-500 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 className="text-4xl md:text-5xl font-bold mb-4">
          Limited Time Sale
        </h2>
        <p className="text-xl mb-8 max-w-2xl mx-auto opacity-90">
          Up to 50% off on selected beauty products. Don't miss out on your favorites!
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12">
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6">
            <div className="text-3xl mb-4">💄</div>
            <h3 className="text-xl font-semibold mb-2">Lipsticks</h3>
            <p className="text-lg opacity-90">Buy 2 Get 1 Free</p>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6">
            <div className="text-3xl mb-4">🧴</div>
            <h3 className="text-xl font-semibold mb-2">Skincare Sets</h3>
            <p className="text-lg opacity-90">40% Off Bundle Deals</p>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6">
            <div className="text-3xl mb-4">🖌️</div>
            <h3 className="text-xl font-semibold mb-2">Brush Sets</h3>
            <p className="text-lg opacity-90">50% Off Professional Sets</p>
          </div>
        </div>

        <div className="mt-12">
          <Button 
            size="lg" 
            className="bg-white text-rose-600 hover:bg-gray-100 px-8 py-4 text-lg font-semibold"
          >
            Shop Sale Now
          </Button>
        </div>
      </div>
    </section>
  );
}
