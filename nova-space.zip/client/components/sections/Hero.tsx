import { Button } from '@/components/ui/button';

export function Hero() {
  return (
    <section id="hero" className="relative min-h-screen flex items-center justify-center bg-gradient-to-br from-rose-50 via-peach-50 to-nude-50">
      <div className="absolute inset-0 opacity-30">
        <div className="w-full h-full bg-gradient-to-r from-rose-100/50 to-peach-100/50"></div>
      </div>
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-5xl md:text-7xl font-bold text-gray-900 mb-6">
            Discover Your
            <span className="block text-rose-600">Perfect Look</span>
          </h1>
          <p className="text-xl md:text-2xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Premium beauty products crafted to enhance your natural radiance and boost your confidence
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              className="bg-rose-600 hover:bg-rose-700 text-white px-8 py-4 text-lg"
              onClick={() => document.getElementById('lipsticks')?.scrollIntoView({ behavior: 'smooth' })}
            >
              Shop Now
            </Button>
            <Button 
              variant="outline" 
              size="lg" 
              className="border-rose-600 text-rose-600 hover:bg-rose-50 px-8 py-4 text-lg"
              onClick={() => document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' })}
            >
              Learn More
            </Button>
          </div>
        </div>

        {/* Featured Product */}
        <div className="mt-16">
          <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-8 shadow-xl max-w-md mx-auto">
            <div className="w-32 h-32 bg-gradient-to-br from-peach-200 to-rose-200 rounded-full mx-auto mb-4 flex items-center justify-center">
              <span className="text-4xl">💄</span>
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">Peach Mango Lip Butter</h3>
            <p className="text-gray-600 mb-4">Nourishing lip treatment with tropical fruit extracts</p>
            <Button className="w-full bg-rose-600 hover:bg-rose-700 text-white">
              Shop Featured Product
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
