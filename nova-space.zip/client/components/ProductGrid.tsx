import { Button } from '@/components/ui/button';

interface Product {
  id: string;
  name: string;
  price: string;
  image: string;
  category: string;
}

interface ProductGridProps {
  products: Product[];
  title: string;
}

export function ProductGrid({ products, title }: ProductGridProps) {
  return (
    <div className="bg-white rounded-lg p-6">
      <h3 className="text-2xl font-semibold text-gray-900 mb-6">{title}</h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {products.map((product) => (
          <div key={product.id} className="group cursor-pointer">
            <div className="aspect-square bg-gradient-to-br from-rose-100 to-peach-100 rounded-lg mb-4 overflow-hidden">
              <div className="w-full h-full flex items-center justify-center text-4xl group-hover:scale-105 transition-transform duration-300">
                {product.image}
              </div>
            </div>
            <h4 className="font-semibold text-gray-900 mb-2 group-hover:text-rose-600 transition-colors">
              {product.name}
            </h4>
            <p className="text-gray-600 mb-3">{product.price}</p>
            <Button 
              size="sm" 
              className="w-full bg-rose-600 hover:bg-rose-700 text-white"
            >
              Add to Cart
            </Button>
          </div>
        ))}
      </div>
    </div>
  );
}
