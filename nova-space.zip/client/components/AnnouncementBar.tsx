export function AnnouncementBar() {
  return (
    <div className="bg-rose-500 text-white py-2 px-4 text-center text-sm font-medium">
      Free Shipping Worldwide 💄 — Shop Now!
    </div>
  );
}
