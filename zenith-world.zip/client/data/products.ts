export interface Product {
  id: string;
  name: string;
  description: string;
  fullDescription: string;
  price: number;
  originalPrice?: number;
  category: 'lipsticks' | 'skincare';
  subcategory: string;
  image: string;
  additionalImages: string[];
  badge?: 'New' | 'Limited' | 'Bestseller' | 'Sale' | 'Low Stock';
  rating: number;
  reviewCount: number;
  inStock: boolean;
  stockCount?: number;
  features: string[];
  ingredients?: string[];
  howToUse?: string;
}

export const sampleProducts: Product[] = [
  // Lipsticks
  {
    id: 'lipstick-1',
    name: 'Velvet Matte Lipstick - Ruby Red',
    description: 'Long-lasting matte finish with rich pigmentation',
    fullDescription: 'Our signature Velvet Matte Lipstick delivers intense color payoff with a comfortable, long-wearing formula. Enriched with vitamin E and jojoba oil for smooth application without drying out your lips.',
    price: 1299,
    category: 'lipsticks',
    subcategory: 'Matte Lipsticks',
    image: 'https://images.unsplash.com/photo-1586495777744-4413f21062fa?w=500&h=500&fit=crop&crop=center',
    additionalImages: [
      'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=500&h=500&fit=crop&crop=center',
      'https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=500&h=500&fit=crop&crop=center'
    ],
    badge: 'Bestseller',
    rating: 4.8,
    reviewCount: 324,
    inStock: true,
    features: ['16-hour wear', 'Transfer-resistant', 'Vitamin E enriched', 'Cruelty-free'],
    ingredients: ['Dimethicone', 'Vitamin E', 'Jojoba Oil', 'Natural Waxes'],
    howToUse: 'Apply directly from the bullet or use a lip brush for precise application. Start from the center of lips and blend outward.'
  },
  {
    id: 'lipstick-2',
    name: 'Glossy Nude Collection',
    description: 'Set of 3 nude glosses for every skin tone',
    fullDescription: 'A curated collection of three complementary nude glosses designed to flatter every Indian skin tone. From warm honey to cool rose undertones.',
    price: 2199,
    originalPrice: 2997,
    category: 'lipsticks',
    subcategory: 'Lip Gloss',
    image: 'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?w=500&h=500&fit=crop&crop=center',
    additionalImages: [
      'https://images.unsplash.com/photo-1631214540242-d9e5b15c8de1?w=500&h=500&fit=crop&crop=center',
      'https://images.unsplash.com/photo-1583241800792-1c74b6da7ed0?w=500&h=500&fit=crop&crop=center'
    ],
    badge: 'Sale',
    rating: 4.9,
    reviewCount: 186,
    inStock: true,
    features: ['Non-sticky formula', 'Buildable coverage', 'Moisturizing', 'Set of 3'],
    howToUse: 'Apply to clean lips using the applicator. Layer for more intense color or wear alone for a natural look.'
  },
  {
    id: 'lipstick-3',
    name: 'Liquid Lipstick - Coral Crush',
    description: 'Vibrant coral shade with satin finish',
    fullDescription: 'A stunning coral liquid lipstick that brightens your complexion. Perfect for day or evening wear with its comfortable satin finish.',
    price: 999,
    category: 'lipsticks',
    subcategory: 'Liquid Lipstick',
    image: 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?w=500&h=500&fit=crop&crop=center',
    additionalImages: [
      'https://images.unsplash.com/photo-1627044315071-2c0e5a6cd5cf?w=500&h=500&fit=crop&crop=center'
    ],
    badge: 'New',
    rating: 4.7,
    reviewCount: 89,
    inStock: true,
    features: ['8-hour wear', 'Lightweight feel', 'Buildable coverage', 'Paraben-free'],
    howToUse: 'Apply in thin layers, allowing each layer to dry before adding more. Use lip liner for precise edges.'
  },
  {
    id: 'lipstick-4',
    name: 'Classic Red Bullet Lipstick',
    description: 'Iconic red shade in creamy formula',
    fullDescription: 'The perfect classic red that works for every occasion. Our creamy formula glides on smoothly and provides rich, even coverage.',
    price: 1599,
    category: 'lipsticks',
    subcategory: 'Classic Lipstick',
    image: 'https://images.unsplash.com/photo-1599003477915-8bcff57d7d5c?w=500&h=500&fit=crop&crop=center',
    additionalImages: [
      'https://images.unsplash.com/photo-1601049541289-9b1b7bbbfe19?w=500&h=500&fit=crop&crop=center'
    ],
    badge: 'Limited',
    rating: 4.6,
    reviewCount: 267,
    inStock: true,
    stockCount: 12,
    features: ['Creamy texture', 'Full coverage', 'Classic packaging', 'Limited edition'],
    howToUse: 'Apply directly from bullet or use a lip brush. Blot with tissue and reapply for longer wear.'
  },

  // Skincare
  {
    id: 'skincare-1',
    name: 'Vitamin C Glow Serum',
    description: 'Brightening serum for radiant skin',
    fullDescription: 'A powerful 20% Vitamin C serum formulated with hyaluronic acid and niacinamide to brighten, hydrate, and even out skin tone. Perfect for achieving that natural glow.',
    price: 2199,
    category: 'skincare',
    subcategory: 'Serums',
    image: 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?w=500&h=500&fit=crop&crop=center',
    additionalImages: [
      'https://images.unsplash.com/photo-1571781926291-c477ebfd024b?w=500&h=500&fit=crop&crop=center',
      'https://images.unsplash.com/photo-1598300042247-d088f8ab3a91?w=500&h=500&fit=crop&crop=center'
    ],
    badge: 'Bestseller',
    rating: 4.9,
    reviewCount: 445,
    inStock: true,
    features: ['20% Vitamin C', 'Anti-aging', 'Brightening', 'Dermatologist tested'],
    ingredients: ['L-Ascorbic Acid', 'Hyaluronic Acid', 'Niacinamide', 'Vitamin E'],
    howToUse: 'Apply 2-3 drops to clean skin before moisturizer. Use in the morning and follow with SPF.'
  },
  {
    id: 'skincare-2',
    name: 'Hydrating Rose Face Mask',
    description: 'Intensive moisture boost with rose water',
    fullDescription: 'Indulge in this luxurious hydrating mask infused with pure rose water, hyaluronic acid, and collagen. Leaves skin soft, plump, and glowing.',
    price: 1599,
    category: 'skincare',
    subcategory: 'Face Masks',
    image: 'https://images.unsplash.com/photo-1570554886111-e80fcca6a029?w=500&h=500&fit=crop&crop=center',
    additionalImages: [
      'https://images.unsplash.com/photo-1556228720-195a672e8a03?w=500&h=500&fit=crop&crop=center'
    ],
    badge: 'New',
    rating: 4.8,
    reviewCount: 156,
    inStock: true,
    features: ['Intense hydration', 'Rose water infused', 'Single-use sachets', 'Suitable for all skin types'],
    ingredients: ['Rose Water', 'Hyaluronic Acid', 'Collagen', 'Aloe Vera'],
    howToUse: 'Apply to clean skin, leave for 15-20 minutes, then rinse with lukewarm water. Use 2-3 times per week.'
  },
  {
    id: 'skincare-3',
    name: 'Gentle Cream Cleanser',
    description: 'Nourishing cleanser for all skin types',
    fullDescription: 'A gentle, non-stripping cream cleanser that removes makeup and impurities while maintaining your skin\'s natural moisture barrier.',
    price: 1299,
    category: 'skincare',
    subcategory: 'Cleansers',
    image: 'https://images.unsplash.com/photo-1608248597279-f99d160bfcbc?w=500&h=500&fit=crop&crop=center',
    additionalImages: [
      'https://images.unsplash.com/photo-1556228852-04b8bb06be5d?w=500&h=500&fit=crop&crop=center'
    ],
    rating: 4.7,
    reviewCount: 298,
    inStock: true,
    features: ['Non-stripping', 'Removes makeup', 'pH balanced', 'Fragrance-free'],
    ingredients: ['Ceramides', 'Glycerin', 'Chamomile Extract', 'Peptides'],
    howToUse: 'Massage onto damp skin, rinse thoroughly with lukewarm water. Use morning and evening.'
  },
  {
    id: 'skincare-4',
    name: 'Night Repair Moisturizer',
    description: 'Anti-aging overnight treatment',
    fullDescription: 'A rich, reparative moisturizer with retinol and peptides that works overnight to reduce fine lines and improve skin texture.',
    price: 2699,
    category: 'skincare',
    subcategory: 'Moisturizers',
    image: 'https://images.unsplash.com/photo-1556228578-dd8b2b45c6ac?w=500&h=500&fit=crop&crop=center',
    additionalImages: [
      'https://images.unsplash.com/photo-1574631092861-b8b0c7c7c25f?w=500&h=500&fit=crop&crop=center'
    ],
    badge: 'Low Stock',
    rating: 4.8,
    reviewCount: 201,
    inStock: true,
    stockCount: 8,
    features: ['Anti-aging', 'Overnight repair', 'Retinol formula', 'Clinically tested'],
    ingredients: ['Retinol', 'Peptides', 'Hyaluronic Acid', 'Ceramides'],
    howToUse: 'Apply to clean skin before bed. Start with 2-3 times per week, gradually increase. Always use SPF the next day.'
  }
];

export const productCategories = [
  {
    id: 'lipsticks',
    name: 'Lipsticks',
    description: 'Premium lipsticks for every mood and occasion',
    subcategories: ['Matte Lipsticks', 'Lip Gloss', 'Liquid Lipstick', 'Classic Lipstick']
  },
  {
    id: 'skincare',
    name: 'Skincare',
    description: 'Science-backed skincare for healthy, glowing skin',
    subcategories: ['Serums', 'Face Masks', 'Cleansers', 'Moisturizers']
  }
];

export function getProductsByCategory(category: string): Product[] {
  return sampleProducts.filter(product => product.category === category);
}

export function getProductById(id: string): Product | undefined {
  return sampleProducts.find(product => product.id === id);
}
