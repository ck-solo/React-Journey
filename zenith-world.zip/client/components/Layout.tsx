import { Link, useLocation } from "react-router-dom";
import { Instagram, Youtube, Twitter, Mail, Heart } from "lucide-react";
import { Button } from "./ui/button";
import { cn } from "@/lib/utils";

interface LayoutProps {
  children: React.ReactNode;
}

const navigationItems = [
  { name: "Home", href: "/" },
  { name: "Lipsticks", href: "/products?category=lipsticks" },
  { name: "Skincare", href: "/products?category=skincare" },
  { name: "About", href: "/about" },
  { name: "Login", href: "/login" },
];

const socialLinks = [
  { icon: Instagram, href: "https://instagram.com", label: "Instagram" },
  { icon: Youtube, href: "https://youtube.com", label: "YouTube" },
  { icon: Twitter, href: "https://twitter.com", label: "Twitter" },
];

export function Layout({ children }: LayoutProps) {
  const location = useLocation();

  return (
    <div className="min-h-screen flex flex-col">
      {/* Sticky Navigation */}
      <nav className="sticky top-0 z-50 glass-effect border-b border-border/50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <Link to="/" className="flex items-center space-x-2 group">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blush-400 to-blush-600 flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                <Heart className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold gradient-text hidden sm:block">
                Aria Beauty
              </span>
            </Link>

            {/* Navigation Links */}
            <div className="hidden md:flex items-center space-x-8">
              {navigationItems.map((item) => (
                <Link
                  key={item.name}
                  to={item.href}
                  className={cn(
                    "text-sm font-medium transition-colors duration-300 hover:text-blush-500 relative",
                    location.pathname === item.href
                      ? "text-blush-500"
                      : "text-foreground/80"
                  )}
                >
                  {item.name}
                  {location.pathname === item.href && (
                    <div className="absolute -bottom-1 left-0 right-0 h-0.5 bg-gradient-to-r from-blush-400 to-blush-600 rounded-full" />
                  )}
                </Link>
              ))}
            </div>

            {/* Mobile Menu Button & Social Icons */}
            <div className="flex items-center space-x-4">
              <div className="hidden sm:flex items-center space-x-3">
                {socialLinks.map((social) => (
                  <a
                    key={social.label}
                    href={social.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-8 h-8 rounded-full bg-blush-100 hover:bg-blush-200 flex items-center justify-center transition-colors duration-300"
                    aria-label={social.label}
                  >
                    <social.icon className="w-4 h-4 text-blush-600" />
                  </a>
                ))}
              </div>

              {/* Mobile Menu (simplified for now) */}
              <div className="md:hidden">
                <Button variant="outline" size="sm" className="px-3">
                  Menu
                </Button>
              </div>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="flex-1">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-gradient-to-r from-cream-50 to-nude-50 border-t border-border/50">
        <div className="container mx-auto px-4 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {/* Brand Section */}
            <div className="md:col-span-2">
              <Link to="/" className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blush-400 to-blush-600 flex items-center justify-center">
                  <Heart className="w-4 h-4 text-white" />
                </div>
                <span className="text-lg font-bold gradient-text">Aria Beauty</span>
              </Link>
              <p className="text-muted-foreground mb-6 max-w-md">
                Discover the beauty within you with our premium collection of lipsticks, 
                skincare, and beauty essentials. Made for the modern Indian woman.
              </p>
              
              {/* Newsletter Signup */}
              <div className="max-w-md">
                <h4 className="font-semibold mb-3">Stay Beautiful</h4>
                <div className="flex gap-2">
                  <input
                    type="email"
                    placeholder="Enter your email"
                    className="flex-1 px-3 py-2 rounded-lg border border-border bg-background/50 focus:outline-none focus:ring-2 focus:ring-blush-500/50 transition-all"
                  />
                  <Button size="sm" className="bg-gradient-to-r from-blush-500 to-blush-600 hover:from-blush-600 hover:to-blush-700 text-white border-0">
                    <Mail className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>

            {/* Quick Links */}
            <div>
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <div className="space-y-2">
                {navigationItems.slice(0, 4).map((item) => (
                  <Link
                    key={item.name}
                    to={item.href}
                    className="block text-muted-foreground hover:text-blush-500 transition-colors"
                  >
                    {item.name}
                  </Link>
                ))}
              </div>
            </div>

            {/* Legal & Contact */}
            <div>
              <h4 className="font-semibold mb-4">Support</h4>
              <div className="space-y-2">
                <Link to="/privacy" className="block text-muted-foreground hover:text-blush-500 transition-colors">
                  Privacy Policy
                </Link>
                <Link to="/terms" className="block text-muted-foreground hover:text-blush-500 transition-colors">
                  Terms of Service
                </Link>
                <a href="mailto:hello@ariabeauty.com" className="block text-muted-foreground hover:text-blush-500 transition-colors">
                  Contact Us
                </a>
                <p className="text-sm text-muted-foreground pt-2">
                  Mumbai, India
                </p>
              </div>
            </div>
          </div>

          {/* Bottom Bar */}
          <div className="border-t border-border/50 mt-8 pt-6 flex flex-col sm:flex-row justify-between items-center">
            <p className="text-sm text-muted-foreground">
              © 2025 Aria Beauty. Made with love in India.
            </p>
            <div className="flex items-center space-x-4 mt-4 sm:mt-0">
              {socialLinks.map((social) => (
                <a
                  key={social.label}
                  href={social.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-8 h-8 rounded-full bg-blush-100 hover:bg-blush-200 flex items-center justify-center transition-colors duration-300"
                  aria-label={social.label}
                >
                  <social.icon className="w-4 h-4 text-blush-600" />
                </a>
              ))}
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
