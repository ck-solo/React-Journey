import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Star, 
  Heart, 
  ShoppingCart, 
  Package, 
  Shield, 
  Truck,
  X,
  ChevronLeft,
  ChevronRight,
  Plus,
  Minus
} from "lucide-react";
import { Product } from "@/data/products";
import { cn } from "@/lib/utils";

interface ProductDetailModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
  onAddToCart?: (product: Product, quantity: number) => void;
  onBuyNow?: (product: Product, quantity: number) => void;
}

export function ProductDetailModal({ 
  product, 
  isOpen, 
  onClose, 
  onAddToCart, 
  onBuyNow 
}: ProductDetailModalProps) {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [isLiked, setIsLiked] = useState(false);

  if (!product) return null;

  const allImages = [product.image, ...product.additionalImages];
  
  const discountPercentage = product.originalPrice 
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : 0;

  const handlePrevImage = () => {
    setCurrentImageIndex((prev) => 
      prev === 0 ? allImages.length - 1 : prev - 1
    );
  };

  const handleNextImage = () => {
    setCurrentImageIndex((prev) => 
      prev === allImages.length - 1 ? 0 : prev + 1
    );
  };

  const handleQuantityChange = (delta: number) => {
    setQuantity(prev => Math.max(1, prev + delta));
  };

  const handleAddToCart = () => {
    onAddToCart?.(product, quantity);
  };

  const handleBuyNow = () => {
    onBuyNow?.(product, quantity);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl w-full h-[90vh] p-0 overflow-hidden">
        <div className="grid grid-cols-1 lg:grid-cols-2 h-full">
          {/* Image Section */}
          <div className="relative bg-gradient-to-br from-cream-50 to-blush-50 p-6 flex flex-col">
            <Button
              variant="ghost"
              size="sm"
              className="absolute top-4 right-4 z-10 w-8 h-8 rounded-full bg-white/80 hover:bg-white"
              onClick={onClose}
            >
              <X className="w-4 h-4" />
            </Button>

            {/* Main Image */}
            <div className="flex-1 flex items-center justify-center relative">
              <div className="relative max-w-md w-full aspect-square">
                <img 
                  src={allImages[currentImageIndex]} 
                  alt={product.name}
                  className="w-full h-full object-cover rounded-2xl shadow-lg"
                />
                
                {/* Image Navigation */}
                {allImages.length > 1 && (
                  <>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="absolute left-2 top-1/2 transform -translate-y-1/2 w-8 h-8 rounded-full bg-white/80 hover:bg-white shadow-md"
                      onClick={handlePrevImage}
                    >
                      <ChevronLeft className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="absolute right-2 top-1/2 transform -translate-y-1/2 w-8 h-8 rounded-full bg-white/80 hover:bg-white shadow-md"
                      onClick={handleNextImage}
                    >
                      <ChevronRight className="w-4 h-4" />
                    </Button>
                  </>
                )}

                {/* Badges */}
                <div className="absolute top-3 left-3 flex flex-col gap-2">
                  {product.badge && (
                    <Badge 
                      className={cn(
                        "text-xs font-medium border-0 shadow-sm",
                        product.badge === 'New' && "bg-green-500 text-white",
                        product.badge === 'Limited' && "bg-purple-500 text-white",
                        product.badge === 'Bestseller' && "bg-yellow-500 text-white",
                        product.badge === 'Sale' && "bg-red-500 text-white",
                        product.badge === 'Low Stock' && "bg-orange-500 text-white"
                      )}
                    >
                      {product.badge}
                    </Badge>
                  )}
                  {discountPercentage > 0 && (
                    <Badge className="bg-red-500 text-white text-xs font-medium border-0">
                      -{discountPercentage}% OFF
                    </Badge>
                  )}
                </div>
              </div>
            </div>

            {/* Image Thumbnails */}
            {allImages.length > 1 && (
              <div className="flex gap-2 mt-4 justify-center">
                {allImages.map((image, index) => (
                  <button
                    key={index}
                    className={cn(
                      "w-16 h-16 rounded-lg overflow-hidden border-2 transition-all",
                      index === currentImageIndex 
                        ? "border-blush-500 scale-105" 
                        : "border-transparent hover:border-blush-300"
                    )}
                    onClick={() => setCurrentImageIndex(index)}
                  >
                    <img 
                      src={image} 
                      alt={`${product.name} ${index + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Product Details Section */}
          <div className="p-6 overflow-y-auto">
            <DialogHeader className="mb-6">
              {/* Category */}
              <p className="text-sm text-blush-600 font-medium uppercase tracking-wide">
                {product.subcategory}
              </p>
              
              {/* Product Name */}
              <DialogTitle className="text-2xl font-bold text-left">
                {product.name}
              </DialogTitle>

              {/* Rating & Reviews */}
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1">
                  {[...Array(5)].map((_, i) => (
                    <Star 
                      key={i} 
                      className={cn(
                        "w-4 h-4",
                        i < Math.floor(product.rating) 
                          ? "text-yellow-400 fill-current" 
                          : "text-gray-300"
                      )} 
                    />
                  ))}
                  <span className="text-sm font-medium ml-1">
                    {product.rating}
                  </span>
                </div>
                <span className="text-sm text-muted-foreground">
                  ({product.reviewCount} reviews)
                </span>
              </div>
            </DialogHeader>

            {/* Price */}
            <div className="mb-6">
              <div className="flex items-center gap-3 mb-2">
                <span className="text-3xl font-bold text-blush-600">
                  ₹{product.price.toLocaleString()}
                </span>
                {product.originalPrice && (
                  <span className="text-lg text-muted-foreground line-through">
                    ₹{product.originalPrice.toLocaleString()}
                  </span>
                )}
              </div>
              {product.stockCount && product.stockCount < 15 && (
                <p className="text-sm text-orange-600">
                  Only {product.stockCount} left in stock!
                </p>
              )}
            </div>

            {/* Description */}
            <div className="mb-6">
              <p className="text-muted-foreground leading-relaxed">
                {product.fullDescription}
              </p>
            </div>

            {/* Features */}
            {product.features && product.features.length > 0 && (
              <div className="mb-6">
                <h4 className="font-semibold mb-3">Key Features</h4>
                <div className="grid grid-cols-2 gap-2">
                  {product.features.map((feature, index) => (
                    <div key={index} className="flex items-center gap-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-blush-500" />
                      <span className="text-sm text-muted-foreground">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Quantity Selector */}
            <div className="mb-6">
              <label className="block text-sm font-medium mb-2">Quantity</label>
              <div className="flex items-center gap-3">
                <div className="flex items-center border border-border rounded-lg">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-10 w-10 rounded-l-lg"
                    onClick={() => handleQuantityChange(-1)}
                    disabled={quantity <= 1}
                  >
                    <Minus className="w-4 h-4" />
                  </Button>
                  <span className="w-12 text-center font-medium">{quantity}</span>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-10 w-10 rounded-r-lg"
                    onClick={() => handleQuantityChange(1)}
                  >
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  className={cn(
                    "w-10 h-10 rounded-lg border",
                    isLiked 
                      ? "border-red-200 bg-red-50 text-red-600" 
                      : "border-border"
                  )}
                  onClick={() => setIsLiked(!isLiked)}
                >
                  <Heart className={cn("w-4 h-4", isLiked && "fill-current")} />
                </Button>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-3 mb-6">
              <Button 
                className="w-full bg-gradient-to-r from-blush-500 to-blush-600 hover:from-blush-600 hover:to-blush-700 text-white border-0 h-12"
                onClick={handleBuyNow}
                disabled={!product.inStock}
              >
                <ShoppingCart className="w-5 h-5 mr-2" />
                Buy Now - ₹{(product.price * quantity).toLocaleString()}
              </Button>
              
              <Button 
                variant="outline" 
                className="w-full border-blush-200 text-blush-700 hover:bg-blush-50 h-12"
                onClick={handleAddToCart}
                disabled={!product.inStock}
              >
                Add to Cart
              </Button>
            </div>

            {/* Additional Info */}
            <Tabs defaultValue="details" className="w-full">
              <TabsList className="grid w-full grid-cols-3 mb-4">
                <TabsTrigger value="details">Details</TabsTrigger>
                <TabsTrigger value="ingredients">Ingredients</TabsTrigger>
                <TabsTrigger value="usage">How to Use</TabsTrigger>
              </TabsList>
              
              <TabsContent value="details" className="space-y-3">
                <div className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg">
                  <Package className="w-5 h-5 text-blush-600" />
                  <div>
                    <p className="font-medium text-sm">Free Shipping</p>
                    <p className="text-xs text-muted-foreground">On orders above ₹999</p>
                  </div>
                </div>
                <div className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg">
                  <Shield className="w-5 h-5 text-green-600" />
                  <div>
                    <p className="font-medium text-sm">Cruelty Free</p>
                    <p className="text-xs text-muted-foreground">Not tested on animals</p>
                  </div>
                </div>
                <div className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg">
                  <Truck className="w-5 h-5 text-blue-600" />
                  <div>
                    <p className="font-medium text-sm">Fast Delivery</p>
                    <p className="text-xs text-muted-foreground">2-3 business days</p>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="ingredients">
                {product.ingredients && product.ingredients.length > 0 ? (
                  <div className="space-y-2">
                    {product.ingredients.map((ingredient, index) => (
                      <div key={index} className="flex items-center gap-2">
                        <div className="w-1.5 h-1.5 rounded-full bg-blush-500" />
                        <span className="text-sm">{ingredient}</span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground">
                    Ingredient information coming soon.
                  </p>
                )}
              </TabsContent>
              
              <TabsContent value="usage">
                {product.howToUse ? (
                  <p className="text-sm leading-relaxed">{product.howToUse}</p>
                ) : (
                  <p className="text-sm text-muted-foreground">
                    Usage instructions coming soon.
                  </p>
                )}
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
