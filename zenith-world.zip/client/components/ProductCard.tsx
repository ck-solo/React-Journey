import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Star, Heart, ShoppingCart, Eye } from "lucide-react";
import { Product } from "@/data/products";
import { cn } from "@/lib/utils";

interface ProductCardProps {
  product: Product;
  onViewDetails: (product: Product) => void;
  onAddToCart?: (product: Product) => void;
  className?: string;
}

export function ProductCard({ product, onViewDetails, onAddToCart, className }: ProductCardProps) {
  const [isLiked, setIsLiked] = useState(false);
  const [imageLoaded, setImageLoaded] = useState(false);

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    onAddToCart?.(product);
  };

  const handleToggleLike = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsLiked(!isLiked);
  };

  const discountPercentage = product.originalPrice 
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : 0;

  return (
    <Card 
      className={cn(
        "group cursor-pointer hover-lift border-0 shadow-md hover:shadow-2xl bg-white/90 backdrop-blur-sm overflow-hidden transition-all duration-500",
        className
      )}
      onClick={() => onViewDetails(product)}
    >
      {/* Product Image */}
      <div className="relative overflow-hidden aspect-square">
        <img 
          src={product.image} 
          alt={product.name}
          className={cn(
            "w-full h-full object-cover group-hover:scale-110 transition-all duration-700 ease-out",
            imageLoaded ? "opacity-100" : "opacity-0"
          )}
          onLoad={() => setImageLoaded(true)}
        />
        
        {/* Image Loading Placeholder */}
        {!imageLoaded && (
          <div className="absolute inset-0 bg-gradient-to-br from-blush-100 to-nude-100 animate-pulse" />
        )}

        {/* Badges */}
        <div className="absolute top-3 left-3 flex flex-col gap-2">
          {product.badge && (
            <Badge 
              className={cn(
                "text-xs font-medium border-0 shadow-sm",
                product.badge === 'New' && "bg-green-100 text-green-700",
                product.badge === 'Limited' && "bg-purple-100 text-purple-700",
                product.badge === 'Bestseller' && "bg-yellow-100 text-yellow-700",
                product.badge === 'Sale' && "bg-red-100 text-red-700",
                product.badge === 'Low Stock' && "bg-orange-100 text-orange-700"
              )}
            >
              {product.badge}
            </Badge>
          )}
          {discountPercentage > 0 && (
            <Badge className="bg-red-500 text-white text-xs font-medium border-0">
              -{discountPercentage}%
            </Badge>
          )}
        </div>

        {/* Action Buttons */}
        <div className="absolute top-3 right-3 flex flex-col gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <Button 
            size="sm" 
            variant="ghost"
            className={cn(
              "w-8 h-8 rounded-full border-0 shadow-md transition-all duration-300",
              isLiked 
                ? "bg-red-100 hover:bg-red-200 text-red-600" 
                : "bg-white/90 hover:bg-white text-gray-600"
            )}
            onClick={handleToggleLike}
          >
            <Heart className={cn("w-4 h-4", isLiked && "fill-current")} />
          </Button>
          
          <Button 
            size="sm" 
            variant="ghost"
            className="w-8 h-8 rounded-full bg-white/90 hover:bg-white text-gray-600 border-0 shadow-md transition-all duration-300"
            onClick={(e) => {
              e.stopPropagation();
              onViewDetails(product);
            }}
          >
            <Eye className="w-4 h-4" />
          </Button>
        </div>

        {/* Quick Add to Cart (appears on hover) */}
        <div className="absolute bottom-3 left-3 right-3 opacity-0 group-hover:opacity-100 transform translate-y-2 group-hover:translate-y-0 transition-all duration-300">
          <Button 
            size="sm" 
            className="w-full bg-blush-500 hover:bg-blush-600 text-white border-0 shadow-lg backdrop-blur-sm"
            onClick={handleAddToCart}
          >
            <ShoppingCart className="w-4 h-4 mr-2" />
            Quick Add
          </Button>
        </div>

        {/* Stock indicator */}
        {!product.inStock && (
          <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
            <Badge className="bg-gray-800 text-white">Out of Stock</Badge>
          </div>
        )}
      </div>

      {/* Product Details */}
      <CardContent className="p-4">
        {/* Rating */}
        <div className="flex items-center gap-1 mb-2">
          {[...Array(5)].map((_, i) => (
            <Star 
              key={i} 
              className={cn(
                "w-3 h-3",
                i < Math.floor(product.rating) 
                  ? "text-yellow-400 fill-current" 
                  : "text-gray-300"
              )} 
            />
          ))}
          <span className="text-xs text-muted-foreground ml-1">
            ({product.reviewCount})
          </span>
        </div>

        {/* Category */}
        <p className="text-xs text-blush-600 font-medium mb-1 uppercase tracking-wide">
          {product.subcategory}
        </p>

        {/* Product Name */}
        <h3 className="font-semibold text-sm mb-2 line-clamp-2 group-hover:text-blush-600 transition-colors">
          {product.name}
        </h3>

        {/* Description */}
        <p className="text-xs text-muted-foreground mb-3 line-clamp-2">
          {product.description}
        </p>

        {/* Price */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-lg font-bold text-blush-600">
              ₹{product.price.toLocaleString()}
            </span>
            {product.originalPrice && (
              <span className="text-sm text-muted-foreground line-through">
                ₹{product.originalPrice.toLocaleString()}
              </span>
            )}
          </div>
          
          {/* Stock status */}
          {product.stockCount && product.stockCount < 15 && (
            <Badge variant="outline" className="text-xs text-orange-600 border-orange-200">
              {product.stockCount} left
            </Badge>
          )}
        </div>

        {/* Features Preview */}
        {product.features && product.features.length > 0 && (
          <div className="mt-3 pt-3 border-t border-border/50">
            <div className="flex flex-wrap gap-1">
              {product.features.slice(0, 2).map((feature, index) => (
                <Badge 
                  key={index}
                  variant="outline" 
                  className="text-xs text-muted-foreground border-border/50 bg-transparent"
                >
                  {feature}
                </Badge>
              ))}
              {product.features.length > 2 && (
                <Badge 
                  variant="outline" 
                  className="text-xs text-muted-foreground border-border/50 bg-transparent"
                >
                  +{product.features.length - 2} more
                </Badge>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
