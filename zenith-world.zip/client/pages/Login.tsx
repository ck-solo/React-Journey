import PlaceholderPage from "./PlaceholderPage";

export default function Login() {
  return (
    <PlaceholderPage 
      title="Login & Signup"
      description="Access your account or create a new one to track orders, save favorites, and get personalized recommendations."
    />
  );
}
