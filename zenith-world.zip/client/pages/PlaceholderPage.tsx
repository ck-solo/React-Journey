import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowLeft, Construction } from "lucide-react";

interface PlaceholderPageProps {
  title: string;
  description: string;
}

export default function PlaceholderPage({ title, description }: PlaceholderPageProps) {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-cream-50 to-blush-50 px-4">
      <Card className="max-w-md w-full text-center glass-effect border-0 shadow-xl">
        <CardContent className="p-8">
          <Construction className="w-16 h-16 text-blush-500 mx-auto mb-6" />
          <h1 className="text-2xl font-bold mb-4">{title}</h1>
          <p className="text-muted-foreground mb-6">{description}</p>
          <p className="text-sm text-muted-foreground mb-6">
            This page is coming soon! Continue prompting to help build out this section.
          </p>
          <Button asChild className="bg-gradient-to-r from-blush-500 to-blush-600 hover:from-blush-600 hover:to-blush-700 text-white border-0">
            <Link to="/">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Home
            </Link>
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
