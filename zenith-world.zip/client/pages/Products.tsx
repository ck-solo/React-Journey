import { useState, useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ProductCard } from "@/components/ProductCard";
import { ProductDetailModal } from "@/components/ProductDetailModal";
import { 
  sampleProducts, 
  productCategories, 
  getProductsByCategory, 
  Product 
} from "@/data/products";
import { 
  Filter, 
  Search, 
  SlidersHorizontal, 
  Grid3X3, 
  List,
  Heart,
  Sparkles
} from "lucide-react";
import { cn } from "@/lib/utils";

export default function Products() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [sortBy, setSortBy] = useState("featured");
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [activeCategory, setActiveCategory] = useState<string>(
    searchParams.get("category") || "lipsticks"
  );

  const filteredProducts = sampleProducts.filter(product => {
    const matchesCategory = product.category === activeCategory;
    const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         product.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const sortedProducts = [...filteredProducts].sort((a, b) => {
    switch (sortBy) {
      case "price-low":
        return a.price - b.price;
      case "price-high":
        return b.price - a.price;
      case "rating":
        return b.rating - a.rating;
      case "newest":
        return a.badge === "New" ? -1 : b.badge === "New" ? 1 : 0;
      default:
        return 0;
    }
  });

  const currentCategory = productCategories.find(cat => cat.id === activeCategory);
  const categoryProducts = getProductsByCategory(activeCategory);

  useEffect(() => {
    const category = searchParams.get("category");
    if (category && category !== activeCategory) {
      setActiveCategory(category);
    }
  }, [searchParams]);

  const handleCategoryChange = (category: string) => {
    setActiveCategory(category);
    setSearchParams({ category });
  };

  const handleViewProduct = (product: Product) => {
    setSelectedProduct(product);
    setIsModalOpen(true);
  };

  const handleAddToCart = (product: Product, quantity: number = 1) => {
    console.log("Add to cart:", product.name, "Quantity:", quantity);
    // Implement add to cart logic
  };

  const handleBuyNow = (product: Product, quantity: number = 1) => {
    console.log("Buy now:", product.name, "Quantity:", quantity);
    // Implement buy now logic
  };

  const getSubcategories = (category: string) => {
    return currentCategory?.subcategories || [];
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-cream-50/50 to-background">
      {/* Hero Section */}
      <section className="py-16 bg-gradient-to-r from-blush-50 to-nude-50">
        <div className="container mx-auto px-4 text-center">
          <Badge className="mb-4 bg-blush-100 text-blush-700 border-blush-200">
            <Sparkles className="w-4 h-4 mr-2" />
            Premium Collection
          </Badge>
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Our <span className="gradient-text">Beauty Collection</span>
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Discover premium makeup and skincare products crafted for the modern Indian woman. 
            Each product is formulated with the finest ingredients for exceptional results.
          </p>
        </div>
      </section>

      <div className="container mx-auto px-4 py-8">
        {/* Category Tabs */}
        <Tabs value={activeCategory} onValueChange={handleCategoryChange} className="mb-8">
          <TabsList className="grid w-full grid-cols-2 max-w-md mx-auto mb-8">
            {productCategories.map((category) => (
              <TabsTrigger 
                key={category.id} 
                value={category.id}
                className="text-sm font-medium"
              >
                {category.name}
              </TabsTrigger>
            ))}
          </TabsList>

          {productCategories.map((category) => (
            <TabsContent key={category.id} value={category.id}>
              {/* Category Header */}
              <div className="text-center mb-12">
                <h2 className="text-3xl font-bold mb-4">{category.name}</h2>
                <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
                  {category.description}
                </p>
              </div>

              {/* Filters and Search */}
              <div className="bg-white/80 backdrop-blur-sm rounded-2xl border border-border/50 p-6 mb-8 shadow-sm">
                <div className="flex flex-col lg:flex-row gap-4 items-center justify-between">
                  {/* Search */}
                  <div className="relative flex-1 max-w-md">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                    <Input
                      placeholder={`Search ${category.name.toLowerCase()}...`}
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10 border-border/50 focus:border-blush-500"
                    />
                  </div>

                  <div className="flex items-center gap-4">
                    {/* Sort */}
                    <Select value={sortBy} onValueChange={setSortBy}>
                      <SelectTrigger className="w-[180px] border-border/50">
                        <SelectValue placeholder="Sort by" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="featured">Featured</SelectItem>
                        <SelectItem value="newest">Newest</SelectItem>
                        <SelectItem value="price-low">Price: Low to High</SelectItem>
                        <SelectItem value="price-high">Price: High to Low</SelectItem>
                        <SelectItem value="rating">Highest Rated</SelectItem>
                      </SelectContent>
                    </Select>

                    {/* View Mode Toggle */}
                    <div className="flex items-center border border-border/50 rounded-lg p-1">
                      <Button
                        variant="ghost"
                        size="sm"
                        className={cn(
                          "w-8 h-8 p-0",
                          viewMode === "grid" && "bg-blush-100 text-blush-700"
                        )}
                        onClick={() => setViewMode("grid")}
                      >
                        <Grid3X3 className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className={cn(
                          "w-8 h-8 p-0",
                          viewMode === "list" && "bg-blush-100 text-blush-700"
                        )}
                        onClick={() => setViewMode("list")}
                      >
                        <List className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>

                {/* Subcategory Filter */}
                {category.subcategories && category.subcategories.length > 0 && (
                  <div className="mt-4 pt-4 border-t border-border/50">
                    <div className="flex flex-wrap gap-2">
                      <Badge 
                        variant="outline" 
                        className="cursor-pointer hover:bg-blush-50 hover:border-blush-300 transition-colors"
                      >
                        All {category.name}
                      </Badge>
                      {category.subcategories.map((subcategory) => (
                        <Badge 
                          key={subcategory}
                          variant="outline" 
                          className="cursor-pointer hover:bg-blush-50 hover:border-blush-300 transition-colors"
                        >
                          {subcategory}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Products Grid */}
              <div className="mb-8">
                <div className="flex items-center justify-between mb-6">
                  <p className="text-muted-foreground">
                    Showing {sortedProducts.length} product{sortedProducts.length !== 1 ? 's' : ''}
                  </p>
                  {searchQuery && (
                    <p className="text-sm text-muted-foreground">
                      Results for "{searchQuery}"
                    </p>
                  )}
                </div>

                {sortedProducts.length > 0 ? (
                  <div className={cn(
                    viewMode === "grid" 
                      ? "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
                      : "space-y-4"
                  )}>
                    {sortedProducts.map((product) => (
                      <ProductCard
                        key={product.id}
                        product={product}
                        onViewDetails={handleViewProduct}
                        onAddToCart={handleAddToCart}
                        className={viewMode === "list" ? "flex-row h-48" : ""}
                      />
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-16">
                    <div className="w-24 h-24 mx-auto mb-6 rounded-full bg-gradient-to-br from-blush-100 to-nude-100 flex items-center justify-center">
                      <Search className="w-8 h-8 text-blush-500" />
                    </div>
                    <h3 className="text-xl font-semibold mb-2">No products found</h3>
                    <p className="text-muted-foreground mb-6">
                      Try adjusting your search or browse our other categories.
                    </p>
                    <Button 
                      variant="outline" 
                      onClick={() => setSearchQuery("")}
                      className="border-blush-200 text-blush-700 hover:bg-blush-50"
                    >
                      Clear Search
                    </Button>
                  </div>
                )}
              </div>

              {/* Featured Section */}
              {category.id === "lipsticks" && (
                <div className="bg-gradient-to-r from-blush-50 to-nude-50 rounded-2xl p-8 text-center">
                  <h3 className="text-2xl font-bold mb-4">
                    💋 Lipstick Lovers Special
                  </h3>
                  <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
                    Get any 3 lipsticks for the price of 2! Mix and match your favorite shades 
                    and build your perfect lip collection.
                  </p>
                  <Badge className="bg-red-500 text-white mb-4">
                    Limited Time Offer
                  </Badge>
                  <br />
                  <Button className="bg-gradient-to-r from-blush-500 to-blush-600 hover:from-blush-600 hover:to-blush-700 text-white border-0">
                    Shop the Deal
                  </Button>
                </div>
              )}

              {category.id === "skincare" && (
                <div className="bg-gradient-to-r from-green-50 to-blue-50 rounded-2xl p-8 text-center">
                  <h3 className="text-2xl font-bold mb-4">
                    ✨ Complete Your Routine
                  </h3>
                  <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
                    Build a complete skincare routine with our curated sets. 
                    Get a personalized consultation with every purchase.
                  </p>
                  <Button className="bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600 text-white border-0">
                    Get Consultation
                  </Button>
                </div>
              )}
            </TabsContent>
          ))}
        </Tabs>
      </div>

      {/* Product Detail Modal */}
      <ProductDetailModal
        product={selectedProduct}
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setSelectedProduct(null);
        }}
        onAddToCart={handleAddToCart}
        onBuyNow={handleBuyNow}
      />
    </div>
  );
}
