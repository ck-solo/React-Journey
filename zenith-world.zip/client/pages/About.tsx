import PlaceholderPage from "./PlaceholderPage";

export default function About() {
  return (
    <PlaceholderPage 
      title="About Aria Beauty"
      description="Learn about our founder's journey, brand mission, and the story behind our premium beauty products."
    />
  );
}
