import { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { 
  ArrowRight, 
  Star, 
  Heart, 
  Sparkles, 
  ShoppingBag,
  Play,
  TrendingUp,
  Award
} from "lucide-react";

export default function Index() {
  const [email, setEmail] = useState("");

  const featuredProducts = [
    {
      id: 1,
      name: "Velvet Matte Lipstick",
      category: "Lipsticks",
      price: "₹1,299",
      image: "https://images.unsplash.com/photo-1586495777744-4413f21062fa?w=300&h=300&fit=crop&crop=center",
      badge: "Bestseller",
      rating: 4.8
    },
    {
      id: 2,
      name: "Glow Serum",
      category: "Skincare",
      price: "₹2,199",
      image: "https://images.unsplash.com/photo-1620916566398-39f1143ab7be?w=300&h=300&fit=crop&crop=center",
      badge: "New",
      rating: 4.9
    },
    {
      id: 3,
      name: "Nude Gloss Collection",
      category: "Lipsticks",
      price: "₹999",
      image: "https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?w=300&h=300&fit=crop&crop=center",
      badge: "Limited",
      rating: 4.7
    }
  ];

  const latestPosts = [
    {
      title: "5 Makeup Trends Taking Over 2025",
      excerpt: "Discover the hottest beauty trends that are defining this year's aesthetic...",
      image: "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=400&h=250&fit=crop&crop=center",
      date: "Jan 15, 2025",
      readTime: "3 min read"
    },
    {
      title: "My Skincare Routine for Glowing Skin",
      excerpt: "The secret to radiant, healthy skin that glows from within...",
      image: "https://images.unsplash.com/photo-1570554886111-e80fcca6a029?w=400&h=250&fit=crop&crop=center",
      date: "Jan 12, 2025",
      readTime: "5 min read"
    }
  ];

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle newsletter signup
    console.log("Newsletter signup:", email);
    setEmail("");
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {/* Background */}
        <div className="absolute inset-0 bg-gradient-to-br from-cream-50 via-background to-blush-50">
          <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZGVmcz48cGF0dGVybiBpZD0iZ3JpZCIgd2lkdGg9IjYwIiBoZWlnaHQ9IjYwIiBwYXR0ZXJuVW5pdHM9InVzZXJTcGFjZU9uVXNlIj48cGF0aCBkPSJNIDYwIDAgTCAwIDAgMCA2MCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSJyZ2JhKDI0NCwgMjI4LCAyMjAsIDAuMykiIHN0cm9rZS13aWR0aD0iMSIvPjwvcGF0dGVybj48L2RlZnM+PHJlY3Qgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgZmlsbD0idXJsKCNncmlkKSIvPjwvc3ZnPg==')] opacity-30" />
        </div>

        {/* Hero Content */}
        <div className="relative z-10 container mx-auto px-4 text-center">
          <div className="max-w-4xl mx-auto">
            {/* Badge */}
            <Badge className="mb-6 bg-blush-100 text-blush-700 border-blush-200 px-4 py-2 text-sm font-medium">
              <Sparkles className="w-4 h-4 mr-2" />
              New Collection Available
            </Badge>

            {/* Main Headline */}
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6 leading-tight">
              Beauty That
              <span className="block gradient-text">Speaks Volumes</span>
            </h1>

            {/* Subtitle */}
            <p className="text-lg md:text-xl text-muted-foreground mb-8 max-w-2xl mx-auto leading-relaxed">
              Discover premium makeup and skincare crafted for the modern Indian woman. 
              From bold lipsticks to nourishing serums, find your perfect beauty match.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
              <Button 
                asChild 
                size="lg" 
                className="bg-gradient-to-r from-blush-500 to-blush-600 hover:from-blush-600 hover:to-blush-700 text-white border-0 px-8 py-6 text-lg hover-lift"
              >
                <Link to="/products">
                  Shop Collection
                  <ShoppingBag className="ml-2 w-5 h-5" />
                </Link>
              </Button>
              
              <Button 
                variant="outline" 
                size="lg" 
                className="border-blush-200 text-blush-700 hover:bg-blush-50 px-8 py-6 text-lg hover-lift"
              >
                <Play className="mr-2 w-5 h-5" />
                Watch Tutorial
              </Button>
            </div>

            {/* Hero Stats */}
            <div className="grid grid-cols-3 gap-8 max-w-md mx-auto">
              <div className="text-center">
                <div className="text-2xl font-bold text-blush-600">50K+</div>
                <div className="text-sm text-muted-foreground">Happy Customers</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-blush-600">4.9★</div>
                <div className="text-sm text-muted-foreground">Average Rating</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-blush-600">100+</div>
                <div className="text-sm text-muted-foreground">Products</div>
              </div>
            </div>
          </div>
        </div>

        {/* Floating Hero Image */}
        <div className="absolute right-0 top-1/2 transform -translate-y-1/2 hidden lg:block">
          <div className="w-80 h-80 rounded-full bg-gradient-to-br from-blush-200 to-blush-300 opacity-20 animate-pulse" />
        </div>
      </section>

      {/* Featured Products Section */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <Badge className="mb-4 bg-nude-100 text-nude-700 border-nude-200">
              <TrendingUp className="w-4 h-4 mr-2" />
              Trending Now
            </Badge>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Our Bestsellers
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Discover the products our customers can't stop talking about. 
              From game-changing lipsticks to skin-transforming serums.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {featuredProducts.map((product) => (
              <Card key={product.id} className="group hover-lift border-0 shadow-md hover:shadow-xl bg-white/80 backdrop-blur-sm">
                <div className="relative overflow-hidden rounded-t-lg">
                  <img 
                    src={product.image} 
                    alt={product.name}
                    className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <Badge className="absolute top-4 left-4 bg-white/90 text-blush-700 border-0">
                    {product.badge}
                  </Badge>
                  <Button 
                    size="sm" 
                    className="absolute top-4 right-4 w-8 h-8 rounded-full bg-white/90 hover:bg-white text-blush-600 border-0 p-0 opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <Heart className="w-4 h-4" />
                  </Button>
                </div>
                <CardContent className="p-6">
                  <div className="flex items-center gap-1 mb-2">
                    {[...Array(5)].map((_, i) => (
                      <Star 
                        key={i} 
                        className={`w-4 h-4 ${i < Math.floor(product.rating) ? 'text-yellow-400 fill-current' : 'text-gray-300'}`} 
                      />
                    ))}
                    <span className="text-sm text-muted-foreground ml-1">({product.rating})</span>
                  </div>
                  <p className="text-sm text-muted-foreground mb-1">{product.category}</p>
                  <h3 className="font-semibold mb-2">{product.name}</h3>
                  <div className="flex items-center justify-between">
                    <span className="text-lg font-bold text-blush-600">{product.price}</span>
                    <Button size="sm" className="bg-blush-500 hover:bg-blush-600 text-white border-0">
                      Add to Cart
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="text-center mt-12">
            <Button asChild variant="outline" size="lg" className="border-blush-200 text-blush-700 hover:bg-blush-50">
              <Link to="/products">
                View All Products
                <ArrowRight className="ml-2 w-5 h-5" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="py-20 bg-gradient-to-r from-blush-50 to-nude-50">
        <div className="container mx-auto px-4 text-center">
          <div className="max-w-2xl mx-auto">
            <Award className="w-12 h-12 text-blush-500 mx-auto mb-6" />
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Join the Beauty Club
            </h2>
            <p className="text-muted-foreground mb-8">
              Get exclusive access to new launches, beauty tips, and special offers. 
              Plus, enjoy 15% off your first order!
            </p>
            
            <form onSubmit={handleNewsletterSubmit} className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your email address"
                className="flex-1 px-4 py-3 rounded-lg border border-border bg-white focus:outline-none focus:ring-2 focus:ring-blush-500/50 transition-all"
                required
              />
              <Button 
                type="submit"
                size="lg"
                className="bg-gradient-to-r from-blush-500 to-blush-600 hover:from-blush-600 hover:to-blush-700 text-white border-0 px-8"
              >
                Subscribe
              </Button>
            </form>
            
            <p className="text-xs text-muted-foreground mt-4">
              No spam, unsubscribe anytime. We respect your privacy.
            </p>
          </div>
        </div>
      </section>

      {/* Latest Content Section */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Latest from the Blog
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Beauty tips, tutorials, and insider secrets to help you look and feel your best.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {latestPosts.map((post, index) => (
              <Card key={index} className="group hover-lift border-0 shadow-md hover:shadow-xl bg-white/80 backdrop-blur-sm">
                <div className="relative overflow-hidden rounded-t-lg">
                  <img 
                    src={post.image} 
                    alt={post.title}
                    className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                </div>
                <CardContent className="p-6">
                  <div className="flex items-center gap-4 text-sm text-muted-foreground mb-3">
                    <span>{post.date}</span>
                    <span>•</span>
                    <span>{post.readTime}</span>
                  </div>
                  <h3 className="text-xl font-semibold mb-3 group-hover:text-blush-600 transition-colors">
                    {post.title}
                  </h3>
                  <p className="text-muted-foreground mb-4">
                    {post.excerpt}
                  </p>
                  <Button variant="ghost" className="text-blush-600 hover:text-blush-700 hover:bg-blush-50 p-0">
                    Read More
                    <ArrowRight className="ml-2 w-4 h-4" />
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
