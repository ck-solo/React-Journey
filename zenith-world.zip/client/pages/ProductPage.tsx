import { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Star, 
  Heart, 
  ShoppingCart, 
  Package, 
  Shield, 
  Truck,
  ChevronLeft,
  ChevronRight,
  Plus,
  Minus,
  ArrowLeft
} from "lucide-react";
import { getProductById, sampleProducts, Product } from "@/data/products";
import { cn } from "@/lib/utils";

export default function ProductPage() {
  const { id } = useParams<{ id: string }>();
  const [product, setProduct] = useState<Product | null>(null);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [isLiked, setIsLiked] = useState(false);

  useEffect(() => {
    if (id) {
      const foundProduct = getProductById(id);
      setProduct(foundProduct || null);
    }
  }, [id]);

  if (!product) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="max-w-md w-full text-center glass-effect border-0 shadow-xl">
          <CardContent className="p-8">
            <h1 className="text-2xl font-bold mb-4">Product Not Found</h1>
            <p className="text-muted-foreground mb-6">
              The product you're looking for doesn't exist.
            </p>
            <Button asChild className="bg-gradient-to-r from-blush-500 to-blush-600 hover:from-blush-600 hover:to-blush-700 text-white border-0">
              <Link to="/products">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Products
              </Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const allImages = [product.image, ...product.additionalImages];
  const relatedProducts = sampleProducts
    .filter(p => p.category === product.category && p.id !== product.id)
    .slice(0, 4);
  
  const discountPercentage = product.originalPrice 
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : 0;

  const handlePrevImage = () => {
    setCurrentImageIndex((prev) => 
      prev === 0 ? allImages.length - 1 : prev - 1
    );
  };

  const handleNextImage = () => {
    setCurrentImageIndex((prev) => 
      prev === allImages.length - 1 ? 0 : prev + 1
    );
  };

  const handleQuantityChange = (delta: number) => {
    setQuantity(prev => Math.max(1, prev + delta));
  };

  const handleAddToCart = () => {
    console.log("Add to cart:", product.name, "Quantity:", quantity);
  };

  const handleBuyNow = () => {
    console.log("Buy now:", product.name, "Quantity:", quantity);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-cream-50/50 to-background">
      {/* Breadcrumb */}
      <div className="container mx-auto px-4 py-6">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Link to="/" className="hover:text-blush-600 transition-colors">Home</Link>
          <span>/</span>
          <Link to="/products" className="hover:text-blush-600 transition-colors">Products</Link>
          <span>/</span>
          <Link 
            to={`/products?category=${product.category}`} 
            className="hover:text-blush-600 transition-colors capitalize"
          >
            {product.category}
          </Link>
          <span>/</span>
          <span className="text-foreground">{product.name}</span>
        </div>
      </div>

      <div className="container mx-auto px-4 pb-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
          {/* Product Images */}
          <div className="space-y-4">
            {/* Main Image */}
            <div className="relative aspect-square bg-gradient-to-br from-cream-50 to-blush-50 rounded-2xl overflow-hidden">
              <img 
                src={allImages[currentImageIndex]} 
                alt={product.name}
                className="w-full h-full object-cover"
              />
              
              {/* Image Navigation */}
              {allImages.length > 1 && (
                <>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="absolute left-4 top-1/2 transform -translate-y-1/2 w-10 h-10 rounded-full bg-white/80 hover:bg-white shadow-md"
                    onClick={handlePrevImage}
                  >
                    <ChevronLeft className="w-5 h-5" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="absolute right-4 top-1/2 transform -translate-y-1/2 w-10 h-10 rounded-full bg-white/80 hover:bg-white shadow-md"
                    onClick={handleNextImage}
                  >
                    <ChevronRight className="w-5 h-5" />
                  </Button>
                </>
              )}

              {/* Badges */}
              <div className="absolute top-4 left-4 flex flex-col gap-2">
                {product.badge && (
                  <Badge 
                    className={cn(
                      "text-sm font-medium border-0 shadow-sm",
                      product.badge === 'New' && "bg-green-500 text-white",
                      product.badge === 'Limited' && "bg-purple-500 text-white",
                      product.badge === 'Bestseller' && "bg-yellow-500 text-white",
                      product.badge === 'Sale' && "bg-red-500 text-white",
                      product.badge === 'Low Stock' && "bg-orange-500 text-white"
                    )}
                  >
                    {product.badge}
                  </Badge>
                )}
                {discountPercentage > 0 && (
                  <Badge className="bg-red-500 text-white text-sm font-medium border-0">
                    -{discountPercentage}% OFF
                  </Badge>
                )}
              </div>
            </div>

            {/* Image Thumbnails */}
            {allImages.length > 1 && (
              <div className="flex gap-3">
                {allImages.map((image, index) => (
                  <button
                    key={index}
                    className={cn(
                      "w-20 h-20 rounded-lg overflow-hidden border-2 transition-all flex-shrink-0",
                      index === currentImageIndex 
                        ? "border-blush-500 scale-105" 
                        : "border-transparent hover:border-blush-300"
                    )}
                    onClick={() => setCurrentImageIndex(index)}
                  >
                    <img 
                      src={image} 
                      alt={`${product.name} ${index + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Product Details */}
          <div className="space-y-6">
            {/* Category */}
            <p className="text-sm text-blush-600 font-medium uppercase tracking-wide">
              {product.subcategory}
            </p>
            
            {/* Product Name */}
            <h1 className="text-3xl lg:text-4xl font-bold">
              {product.name}
            </h1>

            {/* Rating & Reviews */}
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-1">
                {[...Array(5)].map((_, i) => (
                  <Star 
                    key={i} 
                    className={cn(
                      "w-5 h-5",
                      i < Math.floor(product.rating) 
                        ? "text-yellow-400 fill-current" 
                        : "text-gray-300"
                    )} 
                  />
                ))}
                <span className="text-lg font-medium ml-2">
                  {product.rating}
                </span>
              </div>
              <span className="text-muted-foreground">
                ({product.reviewCount} reviews)
              </span>
            </div>

            {/* Price */}
            <div className="space-y-2">
              <div className="flex items-center gap-4">
                <span className="text-4xl font-bold text-blush-600">
                  ₹{product.price.toLocaleString()}
                </span>
                {product.originalPrice && (
                  <span className="text-xl text-muted-foreground line-through">
                    ₹{product.originalPrice.toLocaleString()}
                  </span>
                )}
              </div>
              {product.stockCount && product.stockCount < 15 && (
                <p className="text-orange-600 font-medium">
                  Only {product.stockCount} left in stock!
                </p>
              )}
            </div>

            {/* Description */}
            <p className="text-lg text-muted-foreground leading-relaxed">
              {product.fullDescription}
            </p>

            {/* Features */}
            {product.features && product.features.length > 0 && (
              <div>
                <h3 className="font-semibold text-lg mb-3">Key Features</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {product.features.map((feature, index) => (
                    <div key={index} className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full bg-blush-500 flex-shrink-0" />
                      <span className="text-muted-foreground">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <Separator />

            {/* Quantity Selector */}
            <div>
              <label className="block text-lg font-medium mb-3">Quantity</label>
              <div className="flex items-center gap-4">
                <div className="flex items-center border border-border rounded-lg">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-12 w-12 rounded-l-lg"
                    onClick={() => handleQuantityChange(-1)}
                    disabled={quantity <= 1}
                  >
                    <Minus className="w-5 h-5" />
                  </Button>
                  <span className="w-16 text-center font-medium text-lg">{quantity}</span>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-12 w-12 rounded-r-lg"
                    onClick={() => handleQuantityChange(1)}
                  >
                    <Plus className="w-5 h-5" />
                  </Button>
                </div>
                <Button
                  variant="ghost"
                  size="lg"
                  className={cn(
                    "h-12 w-12 rounded-lg border",
                    isLiked 
                      ? "border-red-200 bg-red-50 text-red-600" 
                      : "border-border"
                  )}
                  onClick={() => setIsLiked(!isLiked)}
                >
                  <Heart className={cn("w-5 h-5", isLiked && "fill-current")} />
                </Button>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-4">
              <Button 
                size="lg"
                className="w-full bg-gradient-to-r from-blush-500 to-blush-600 hover:from-blush-600 hover:to-blush-700 text-white border-0 h-14 text-lg"
                onClick={handleBuyNow}
                disabled={!product.inStock}
              >
                <ShoppingCart className="w-5 h-5 mr-2" />
                Buy Now - ₹{(product.price * quantity).toLocaleString()}
              </Button>
              
              <Button 
                variant="outline" 
                size="lg"
                className="w-full border-blush-200 text-blush-700 hover:bg-blush-50 h-14 text-lg"
                onClick={handleAddToCart}
                disabled={!product.inStock}
              >
                Add to Cart
              </Button>
            </div>

            {/* Additional Info Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="flex items-center gap-3 p-4 bg-muted/50 rounded-lg">
                <Package className="w-6 h-6 text-blush-600 flex-shrink-0" />
                <div>
                  <p className="font-medium">Free Shipping</p>
                  <p className="text-sm text-muted-foreground">Orders above ₹999</p>
                </div>
              </div>
              <div className="flex items-center gap-3 p-4 bg-muted/50 rounded-lg">
                <Shield className="w-6 h-6 text-green-600 flex-shrink-0" />
                <div>
                  <p className="font-medium">Cruelty Free</p>
                  <p className="text-sm text-muted-foreground">Ethically made</p>
                </div>
              </div>
              <div className="flex items-center gap-3 p-4 bg-muted/50 rounded-lg">
                <Truck className="w-6 h-6 text-blue-600 flex-shrink-0" />
                <div>
                  <p className="font-medium">Fast Delivery</p>
                  <p className="text-sm text-muted-foreground">2-3 business days</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Product Details Tabs */}
        <div className="mb-16">
          <Tabs defaultValue="ingredients" className="w-full">
            <TabsList className="grid w-full grid-cols-3 max-w-md mx-auto mb-8">
              <TabsTrigger value="ingredients">Ingredients</TabsTrigger>
              <TabsTrigger value="usage">How to Use</TabsTrigger>
              <TabsTrigger value="reviews">Reviews</TabsTrigger>
            </TabsList>
            
            <div className="bg-white/80 backdrop-blur-sm rounded-2xl border border-border/50 p-8">
              <TabsContent value="ingredients">
                {product.ingredients && product.ingredients.length > 0 ? (
                  <div className="space-y-4">
                    <h3 className="text-xl font-semibold mb-4">Full Ingredient List</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {product.ingredients.map((ingredient, index) => (
                        <div key={index} className="flex items-center gap-3">
                          <div className="w-2 h-2 rounded-full bg-blush-500 flex-shrink-0" />
                          <span>{ingredient}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <p className="text-muted-foreground">
                      Detailed ingredient information coming soon.
                    </p>
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="usage">
                {product.howToUse ? (
                  <div className="space-y-4">
                    <h3 className="text-xl font-semibold mb-4">How to Use</h3>
                    <p className="text-lg leading-relaxed">{product.howToUse}</p>
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <p className="text-muted-foreground">
                      Usage instructions coming soon.
                    </p>
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="reviews">
                <div className="text-center py-8">
                  <h3 className="text-xl font-semibold mb-4">Customer Reviews</h3>
                  <p className="text-muted-foreground">
                    Review system coming soon. Current rating: {product.rating}/5 from {product.reviewCount} customers.
                  </p>
                </div>
              </TabsContent>
            </div>
          </Tabs>
        </div>

        {/* Related Products */}
        {relatedProducts.length > 0 && (
          <div>
            <h2 className="text-2xl font-bold text-center mb-8">You Might Also Like</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {relatedProducts.map((relatedProduct) => (
                <Link key={relatedProduct.id} to={`/product/${relatedProduct.id}`}>
                  <Card className="group hover-lift border-0 shadow-md hover:shadow-xl bg-white/80 backdrop-blur-sm">
                    <div className="relative overflow-hidden aspect-square rounded-t-lg">
                      <img 
                        src={relatedProduct.image} 
                        alt={relatedProduct.name}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                      />
                    </div>
                    <CardContent className="p-4">
                      <h3 className="font-semibold mb-2 line-clamp-2 group-hover:text-blush-600 transition-colors">
                        {relatedProduct.name}
                      </h3>
                      <p className="text-lg font-bold text-blush-600">
                        ₹{relatedProduct.price.toLocaleString()}
                      </p>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
