import { PlaceholderPage } from "@/components/PlaceholderPage";

export default function Sale() {
  return (
    <PlaceholderPage
      title="Sale Collection"
      description="Don't miss out on amazing deals! Shop our bestselling products at incredible prices. Limited time offers on your favorite beauty essentials."
    />
  );
}
