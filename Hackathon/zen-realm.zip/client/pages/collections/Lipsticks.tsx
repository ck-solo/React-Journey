import { PlaceholderPage } from "@/components/PlaceholderPage";

export default function Lipsticks() {
  return (
    <PlaceholderPage
      title="Lipsticks Collection"
      description="Discover our full range of premium lipsticks with rich colors and long-lasting formula. From bold reds to subtle nudes, find your perfect shade."
    />
  );
}
