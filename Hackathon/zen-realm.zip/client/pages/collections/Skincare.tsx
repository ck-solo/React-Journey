import { PlaceholderPage } from "@/components/PlaceholderPage";

export default function Skincare() {
  return (
    <PlaceholderPage
      title="Skincare Collection"
      description="Nourish your skin with our premium skincare line. From hydrating serums to rejuvenating masks, achieve your healthiest glow."
    />
  );
}
