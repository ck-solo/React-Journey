import { PlaceholderPage } from "@/components/PlaceholderPage";

export default function Accessories() {
  return (
    <PlaceholderPage
      title="Accessories Collection"
      description="Complete your beauty routine with our premium accessories. From makeup brushes to beauty tools, everything you need for a flawless application."
    />
  );
}
