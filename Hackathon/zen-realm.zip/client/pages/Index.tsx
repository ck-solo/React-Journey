import { HeroSection } from "@/components/HeroSection";
import { ProductCollections } from "@/components/ProductCollections";
import { ProductCarousel } from "@/components/ProductCarousel";
import { AboutSection } from "@/components/AboutSection";

export default function Index() {
  return (
    <div>
      <section id="home">
        <HeroSection />
      </section>
      <section id="lipsticks">
        <ProductCollections />
      </section>
      <section id="featured">
        <ProductCarousel />
      </section>
      <section id="about">
        <AboutSection />
      </section>
    </div>
  );
}
