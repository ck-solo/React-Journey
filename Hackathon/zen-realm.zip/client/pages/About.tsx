import { PlaceholderPage } from "@/components/PlaceholderPage";

export default function About() {
  return (
    <PlaceholderPage
      title="About Us"
      description="Learn more about our brand story, values, and commitment to creating premium beauty products that enhance your natural radiance."
    />
  );
}
