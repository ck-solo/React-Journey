import { ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";

const collections = [
  {
    name: "Lipsticks",
    description: "Bold colors, long-lasting wear",
    image: "💄",
    href: "/collections/lipsticks",
    color: "from-beauty-pink-100 to-beauty-pink-200",
  },
  {
    name: "Skincare",
    description: "Nourish and glow naturally",
    image: "🧴",
    href: "/collections/skincare",
    color: "from-beauty-peach-100 to-beauty-peach-200",
  },
  {
    name: "Sale",
    description: "Up to 50% off bestsellers",
    image: "🏷️",
    href: "/collections/sale",
    color: "from-red-100 to-red-200",
  },
  {
    name: "Accessories",
    description: "Complete your beauty routine",
    image: "💫",
    href: "/collections/accessories",
    color: "from-beauty-nude-100 to-beauty-nude-200",
  },
];

export function ProductCollections() {
  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
            Shop Collections
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Discover our curated collections of premium beauty products, 
            each designed to enhance your natural radiance.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {collections.map((collection) => (
            <Link
              key={collection.name}
              to={collection.href}
              className="group beauty-card"
            >
              <div className={`bg-gradient-to-br ${collection.color} h-48 flex items-center justify-center relative overflow-hidden`}>
                <div className="text-6xl group-hover:scale-110 transition-transform duration-300">
                  {collection.image}
                </div>
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors duration-300" />
              </div>
              
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-2 group-hover:text-primary transition-colors duration-300">
                  {collection.name}
                </h3>
                <p className="text-gray-600 mb-4 text-sm leading-relaxed">
                  {collection.description}
                </p>
                <div className="flex items-center text-primary font-medium group-hover:translate-x-1 transition-transform duration-300">
                  Shop Now
                  <ArrowRight size={16} className="ml-1" />
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
