export function AboutSection() {
  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Text Content */}
          <div>
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-6">
              Our Beauty Story
            </h2>
            <p className="text-lg text-gray-600 mb-6 leading-relaxed">
              Founded with a passion for enhancing natural beauty, Bella Beauty 
              believes that every person deserves to feel confident and radiant. 
              Our journey began with a simple mission: to create high-quality, 
              accessible beauty products that celebrate individuality.
            </p>
            <p className="text-lg text-gray-600 mb-8 leading-relaxed">
              From our signature lip collections to our nourishing skincare line, 
              each product is carefully formulated with premium ingredients and 
              tested for exceptional performance. We're committed to cruelty-free 
              practices and sustainable packaging.
            </p>
            
            <div className="grid grid-cols-3 gap-6 mb-8">
              <div className="text-center">
                <div className="text-2xl font-bold text-primary mb-1">500K+</div>
                <div className="text-sm text-gray-600">Happy Customers</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-primary mb-1">50+</div>
                <div className="text-sm text-gray-600">Products</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-primary mb-1">100%</div>
                <div className="text-sm text-gray-600">Cruelty-Free</div>
              </div>
            </div>

            <button className="beauty-button">
              Learn Our Story
            </button>
          </div>

          {/* Image/Visual Content */}
          <div className="relative">
            <div className="bg-gradient-to-br from-beauty-peach-100 to-beauty-pink-100 rounded-3xl p-8 shadow-xl">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-4">
                  <div className="bg-white rounded-2xl p-6 shadow-sm">
                    <div className="text-4xl mb-2">🌿</div>
                    <div className="text-sm font-medium text-gray-900">Natural</div>
                    <div className="text-xs text-gray-600">Ingredients</div>
                  </div>
                  <div className="bg-white rounded-2xl p-6 shadow-sm">
                    <div className="text-4xl mb-2">💎</div>
                    <div className="text-sm font-medium text-gray-900">Premium</div>
                    <div className="text-xs text-gray-600">Quality</div>
                  </div>
                </div>
                <div className="space-y-4 pt-8">
                  <div className="bg-white rounded-2xl p-6 shadow-sm">
                    <div className="text-4xl mb-2">🐰</div>
                    <div className="text-sm font-medium text-gray-900">Cruelty</div>
                    <div className="text-xs text-gray-600">Free</div>
                  </div>
                  <div className="bg-white rounded-2xl p-6 shadow-sm">
                    <div className="text-4xl mb-2">♻️</div>
                    <div className="text-sm font-medium text-gray-900">Sustainable</div>
                    <div className="text-xs text-gray-600">Packaging</div>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Floating elements */}
            <div className="absolute -top-4 -right-4 bg-white rounded-full p-3 shadow-lg">
              <span className="text-2xl">✨</span>
            </div>
            <div className="absolute -bottom-4 -left-4 bg-white rounded-full p-3 shadow-lg">
              <span className="text-2xl">💕</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
