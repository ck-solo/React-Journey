import { X } from "lucide-react";
import { useState } from "react";

export function AnnouncementBar() {
  const [isVisible, setIsVisible] = useState(true);

  if (!isVisible) return null;

  return (
    <div className="bg-beauty-peach-100 text-beauty-peach-500 py-2 px-4 text-center text-sm font-medium relative">
      <div className="max-w-4xl mx-auto">
        ✨ Free shipping on orders over $50 | New Peach Mango Collection now available
      </div>
      <button
        onClick={() => setIsVisible(false)}
        className="absolute right-4 top-1/2 transform -translate-y-1/2 hover:opacity-70 transition-opacity"
        aria-label="Close announcement"
      >
        <X size={16} />
      </button>
    </div>
  );
}
