import { Star } from "lucide-react";

const featuredProducts = [
  {
    id: 1,
    name: "Glossy Pink Lip Kit",
    price: 32,
    originalPrice: null,
    image: "💖",
    label: "New",
    labelType: "new" as const,
    rating: 4.8,
    reviews: 124,
  },
  {
    id: 2,
    name: "Matte Nude Lipstick",
    price: 22,
    originalPrice: null,
    image: "💋",
    label: "Kylie's Favourite",
    labelType: "favourite" as const,
    rating: 4.9,
    reviews: 89,
  },
  {
    id: 3,
    name: "Vitamin C Serum",
    price: 45,
    originalPrice: null,
    image: "🧪",
    label: "Low Stock",
    labelType: "low-stock" as const,
    rating: 4.7,
    reviews: 203,
  },
  {
    id: 4,
    name: "Berry Lip Gloss",
    price: 18,
    originalPrice: 25,
    image: "🍓",
    label: "Sale",
    labelType: "new" as const,
    rating: 4.6,
    reviews: 67,
  },
  {
    id: 5,
    name: "Bronzing Powder",
    price: 0,
    originalPrice: 35,
    image: "☀️",
    label: "Sold Out",
    labelType: "sold-out" as const,
    rating: 4.8,
    reviews: 156,
  },
  {
    id: 6,
    name: "Hydrating Face Mask",
    price: 28,
    originalPrice: null,
    image: "🥒",
    label: "New",
    labelType: "new" as const,
    rating: 4.9,
    reviews: 91,
  },
];

export function ProductCarousel() {
  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
            Featured Products
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Discover our latest launches and bestselling favorites, 
            handpicked for their exceptional quality and performance.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-6">
          {featuredProducts.map((product) => (
            <div key={product.id} className="beauty-card group cursor-pointer relative">
              {/* Product Label */}
              <div className={`product-label ${
                product.labelType === 'new' ? 'label-new' :
                product.labelType === 'favourite' ? 'label-favourite' :
                product.labelType === 'low-stock' ? 'label-low-stock' :
                'label-sold-out'
              }`}>
                {product.label}
              </div>

              {/* Product Image */}
              <div className="bg-gradient-to-br from-gray-100 to-gray-200 h-48 flex items-center justify-center relative overflow-hidden">
                <div className="text-6xl group-hover:scale-110 transition-transform duration-300">
                  {product.image}
                </div>
                {product.labelType === 'sold-out' && (
                  <div className="absolute inset-0 bg-black/20 flex items-center justify-center">
                    <span className="text-white font-bold text-lg">Sold Out</span>
                  </div>
                )}
              </div>

              {/* Product Info */}
              <div className="p-4">
                <h3 className="font-semibold text-gray-900 mb-2 text-sm leading-tight">
                  {product.name}
                </h3>
                
                <div className="flex items-center mb-2">
                  <div className="flex items-center">
                    {[...Array(5)].map((_, i) => (
                      <Star 
                        key={i} 
                        size={12} 
                        className={i < Math.floor(product.rating) ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'} 
                      />
                    ))}
                    <span className="ml-1 text-xs text-gray-600">({product.reviews})</span>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {product.price > 0 ? (
                      <>
                        <span className="font-bold text-gray-900">${product.price}</span>
                        {product.originalPrice && (
                          <span className="text-sm text-gray-500 line-through">
                            ${product.originalPrice}
                          </span>
                        )}
                      </>
                    ) : (
                      <span className="text-gray-500 font-medium">Sold Out</span>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <button className="beauty-button">
            View All Products
          </button>
        </div>
      </div>
    </section>
  );
}
