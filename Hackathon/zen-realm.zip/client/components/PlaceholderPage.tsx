import { ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";

interface PlaceholderPageProps {
  title: string;
  description: string;
}

export function PlaceholderPage({ title, description }: PlaceholderPageProps) {
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center py-16">
      <div className="max-w-md w-full mx-auto text-center px-4">
        <div className="beauty-card p-8">
          <div className="text-6xl mb-6">🚧</div>
          <h1 className="text-2xl font-bold text-gray-900 mb-4">{title}</h1>
          <p className="text-gray-600 mb-8 leading-relaxed">{description}</p>
          <p className="text-sm text-gray-500 mb-6">
            This page is coming soon! Continue prompting to have us build out this section.
          </p>
          <Link 
            to="/" 
            className="inline-flex items-center gap-2 beauty-button"
          >
            <ArrowLeft size={16} />
            Back to Home
          </Link>
        </div>
      </div>
    </div>
  );
}
