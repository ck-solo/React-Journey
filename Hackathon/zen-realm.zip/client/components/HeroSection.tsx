import { Star } from "lucide-react";

export function HeroSection() {
  return (
    <section className="beauty-gradient py-16 lg:py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Text Content */}
          <div className="order-2 lg:order-1">
            <div className="inline-flex items-center bg-white/80 backdrop-blur-sm px-4 py-2 rounded-full text-sm font-medium text-beauty-peach-500 mb-6">
              ✨ New Launch
            </div>
            
            <h1 className="text-4xl lg:text-6xl font-bold text-gray-900 mb-6 leading-tight">
              Peach Mango
              <span className="block text-primary">Lip Butter</span>
            </h1>
            
            <p className="text-lg text-gray-600 mb-8 leading-relaxed">
              Our most luxurious lip butter yet. Infused with nourishing peach and mango extracts 
              for silky-smooth lips with a gorgeous natural tint. Long-lasting moisture with a 
              subtle tropical scent.
            </p>

            <div className="flex items-center gap-4 mb-8">
              <div className="flex items-center">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} size={16} className="fill-yellow-400 text-yellow-400" />
                ))}
                <span className="ml-2 text-sm text-gray-600">(247 reviews)</span>
              </div>
              <div className="text-2xl font-bold text-gray-900">$24</div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <button className="beauty-button">
                Shop Now
              </button>
              <button className="px-6 py-3 border-2 border-gray-300 text-gray-700 rounded-full font-medium hover:border-primary hover:text-primary transition-all duration-300">
                Learn More
              </button>
            </div>
          </div>

          {/* Product Image */}
          <div className="order-1 lg:order-2 relative">
            <div className="relative bg-white/20 backdrop-blur-sm rounded-3xl p-8 shadow-2xl">
              <div className="aspect-square bg-gradient-to-br from-beauty-peach-200 to-beauty-pink-200 rounded-2xl flex items-center justify-center">
                <div className="w-48 h-48 bg-gradient-to-b from-beauty-peach-400 to-beauty-peach-500 rounded-full flex items-center justify-center shadow-xl">
                  <div className="text-white text-center">
                    <div className="text-4xl font-bold mb-2">🥭</div>
                    <div className="text-sm font-medium">Peach Mango</div>
                    <div className="text-xs opacity-90">Lip Butter</div>
                  </div>
                </div>
              </div>
              
              {/* Floating elements */}
              <div className="absolute -top-4 -right-4 bg-white rounded-full p-3 shadow-lg">
                <span className="text-2xl">✨</span>
              </div>
              <div className="absolute -bottom-4 -left-4 bg-white rounded-full p-3 shadow-lg">
                <span className="text-2xl">🍑</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
