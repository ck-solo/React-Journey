export interface Product {
  id: string;
  name: string;
  price: number;
  originalPrice?: number;
  description: string;
  category: 'lipsticks' | 'skincare' | 'accessories';
  image: string;
  images: string[];
  label?: 'New' | 'Sold Out' | 'Low Stock' | 'Sale' | "Kylie's Favourite";
  labelType?: 'new' | 'sold-out' | 'low-stock' | 'sale' | 'favourite';
  rating: number;
  reviews: number;
  stock: number;
  featured: boolean;
  ingredients?: string[];
  shades?: Array<{ name: string; color: string }>;
}

export const products: Product[] = [
  // Lipsticks
  {
    id: "peach-mango-lip-butter",
    name: "Peach Mango Lip Butter",
    price: 24,
    description: "Our most luxurious lip butter yet. Infused with nourishing peach and mango extracts for silky-smooth lips with a gorgeous natural tint. Long-lasting moisture with a subtle tropical scent.",
    category: "lipsticks",
    image: "🥭",
    images: ["🥭", "🍑", "✨"],
    label: "New",
    labelType: "new",
    rating: 4.8,
    reviews: 247,
    stock: 15,
    featured: true,
    ingredients: ["Peach Extract", "Mango Butter", "Vitamin E", "Jojoba Oil"],
    shades: [
      { name: "Peach Dream", color: "#FFB07A" },
      { name: "Mango Sunset", color: "#FF8C42" }
    ]
  },
  {
    id: "glossy-pink-lip-kit",
    name: "Glossy Pink Lip Kit",
    price: 32,
    description: "Get the perfect glossy pink pout with our iconic lip kit. Includes lip liner and high-shine gloss for a long-lasting, mirror-like finish.",
    category: "lipsticks",
    image: "💖",
    images: ["💖", "💋", "✨"],
    label: "Kylie's Favourite",
    labelType: "favourite",
    rating: 4.9,
    reviews: 124,
    stock: 8,
    featured: true,
    ingredients: ["Hyaluronic Acid", "Vitamin E", "Coconut Oil"],
    shades: [
      { name: "Bubblegum", color: "#FFB6C1" },
      { name: "Rose Gold", color: "#E8B4CB" }
    ]
  },
  {
    id: "matte-nude-lipstick",
    name: "Matte Nude Lipstick",
    price: 22,
    description: "The perfect everyday nude with a velvety matte finish. Comfortable wear that doesn't dry out your lips.",
    category: "lipsticks",
    image: "💋",
    images: ["💋", "🤎", "✨"],
    rating: 4.7,
    reviews: 89,
    stock: 25,
    featured: true,
    ingredients: ["Shea Butter", "Argan Oil", "Vitamin C"],
    shades: [
      { name: "Nude Bliss", color: "#D2B48C" },
      { name: "Caramel Kiss", color: "#C8A882" }
    ]
  },
  {
    id: "berry-lip-gloss",
    name: "Berry Lip Gloss",
    price: 18,
    originalPrice: 25,
    description: "Juicy berry gloss with incredible shine and a delicious scent. Perfect for layering or wearing alone.",
    category: "lipsticks",
    image: "🍓",
    images: ["🍓", "🫐", "✨"],
    label: "Sale",
    labelType: "sale",
    rating: 4.6,
    reviews: 67,
    stock: 12,
    featured: true,
    ingredients: ["Berry Extract", "Peptides", "Coconut Oil"],
    shades: [
      { name: "Wild Berry", color: "#8B008B" },
      { name: "Cherry Pop", color: "#DC143C" }
    ]
  },
  {
    id: "red-velvet-lipstick",
    name: "Red Velvet Lipstick",
    price: 26,
    description: "Bold, classic red with a luxurious velvet finish. Make a statement with this timeless shade.",
    category: "lipsticks",
    image: "🌹",
    images: ["🌹", "❤️", "✨"],
    rating: 4.8,
    reviews: 156,
    stock: 18,
    featured: false,
    ingredients: ["Rose Hip Oil", "Vitamin E", "Beeswax"],
    shades: [
      { name: "Classic Red", color: "#DC143C" },
      { name: "Deep Burgundy", color: "#800020" }
    ]
  },
  {
    id: "coral-crush-lipstick",
    name: "Coral Crush Lipstick",
    price: 24,
    description: "Vibrant coral that brightens your complexion. Perfect for spring and summer looks.",
    category: "lipsticks",
    image: "🪸",
    images: ["🪸", "🧡", "✨"],
    rating: 4.5,
    reviews: 92,
    stock: 22,
    featured: false,
    ingredients: ["Coral Extract", "Vitamin C", "Jojoba Oil"],
    shades: [
      { name: "Coral Reef", color: "#FF7F50" },
      { name: "Sunset Coral", color: "#FF6347" }
    ]
  },

  // Skincare
  {
    id: "vitamin-c-serum",
    name: "Vitamin C Brightening Serum",
    price: 45,
    description: "Powerful vitamin C serum that brightens skin and reduces dark spots. Clinically proven to improve skin tone in 4 weeks.",
    category: "skincare",
    image: "🧪",
    images: ["🧪", "☀️", "✨"],
    label: "Low Stock",
    labelType: "low-stock",
    rating: 4.7,
    reviews: 203,
    stock: 3,
    featured: true,
    ingredients: ["20% Vitamin C", "Hyaluronic Acid", "Vitamin E", "Ferulic Acid"]
  },
  {
    id: "hydrating-face-mask",
    name: "Hydrating Honey Face Mask",
    price: 28,
    description: "Deeply moisturizing face mask with raw honey and botanical extracts. Leaves skin soft and glowing.",
    category: "skincare",
    image: "🥒",
    images: ["🥒", "🍯", "✨"],
    label: "New",
    labelType: "new",
    rating: 4.9,
    reviews: 91,
    stock: 16,
    featured: true,
    ingredients: ["Raw Honey", "Cucumber Extract", "Aloe Vera", "Chamomile"]
  },
  {
    id: "retinol-night-cream",
    name: "Retinol Night Renewal Cream",
    price: 52,
    description: "Advanced anti-aging night cream with gentle retinol. Reduces fine lines and improves skin texture while you sleep.",
    category: "skincare",
    image: "🌙",
    images: ["🌙", "⭐", "✨"],
    rating: 4.8,
    reviews: 167,
    stock: 14,
    featured: false,
    ingredients: ["Retinol", "Peptides", "Ceramides", "Niacinamide"]
  },
  {
    id: "gentle-cleanser",
    name: "Gentle Foaming Cleanser",
    price: 22,
    description: "Sulfate-free cleanser that removes makeup and impurities without stripping skin's natural moisture.",
    category: "skincare",
    image: "🫧",
    images: ["🫧", "💧", "✨"],
    rating: 4.6,
    reviews: 134,
    stock: 28,
    featured: false,
    ingredients: ["Coconut-derived Surfactants", "Glycerin", "Chamomile", "Green Tea"]
  },
  {
    id: "sunscreen-spf50",
    name: "Daily Defense SPF 50",
    price: 32,
    description: "Lightweight, non-greasy sunscreen with broad-spectrum protection. Perfect under makeup or worn alone.",
    category: "skincare",
    image: "☀️",
    images: ["☀️", "🛡️", "✨"],
    rating: 4.7,
    reviews: 198,
    stock: 21,
    featured: false,
    ingredients: ["Zinc Oxide", "Titanium Dioxide", "Vitamin E", "Aloe Vera"]
  },

  // Accessories
  {
    id: "makeup-brush-set",
    name: "Professional Makeup Brush Set",
    price: 68,
    description: "Complete 12-piece brush set made with premium synthetic bristles. Includes face and eye brushes in a travel case.",
    category: "accessories",
    image: "🖌️",
    images: ["🖌️", "💄", "✨"],
    rating: 4.8,
    reviews: 89,
    stock: 11,
    featured: false,
    ingredients: ["Synthetic Bristles", "Aluminum Ferrules", "Bamboo Handles"]
  },
  {
    id: "beauty-sponge-set",
    name: "Beauty Blender Sponge Set",
    price: 24,
    description: "Set of 3 latex-free beauty sponges for flawless foundation application. Use damp for a natural finish.",
    category: "accessories",
    image: "🧽",
    images: ["🧽", "💧", "✨"],
    label: "New",
    labelType: "new",
    rating: 4.5,
    reviews: 156,
    stock: 35,
    featured: false
  },
  {
    id: "led-mirror",
    name: "LED Vanity Mirror",
    price: 89,
    description: "Professional LED mirror with adjustable brightness and 10x magnification. Perfect for precise makeup application.",
    category: "accessories",
    image: "🪞",
    images: ["🪞", "💡", "✨"],
    rating: 4.9,
    reviews: 76,
    stock: 7,
    featured: false
  },
  {
    id: "travel-case",
    name: "Luxury Travel Makeup Case",
    price: 45,
    description: "Elegant makeup organizer with multiple compartments and a mirror. Perfect for travel or home organization.",
    category: "accessories",
    image: "👝",
    images: ["👝", "✈️", "✨"],
    rating: 4.6,
    reviews: 123,
    stock: 19,
    featured: false
  },

  // Special/Sale Items
  {
    id: "bronzing-powder",
    name: "Golden Hour Bronzing Powder",
    price: 0,
    originalPrice: 35,
    description: "Limited edition bronzing powder that's currently sold out. Get notified when it's back in stock!",
    category: "accessories",
    image: "☀️",
    images: ["☀️", "✨", "💫"],
    label: "Sold Out",
    labelType: "sold-out",
    rating: 4.8,
    reviews: 156,
    stock: 0,
    featured: true,
    ingredients: ["Mica", "Iron Oxides", "Coconut Oil", "Vitamin E"]
  }
];

export const getProductById = (id: string): Product | undefined => {
  return products.find(product => product.id === id);
};

export const getProductsByCategory = (category: string): Product[] => {
  return products.filter(product => product.category === category);
};

export const getFeaturedProducts = (): Product[] => {
  return products.filter(product => product.featured);
};

export const getNewProducts = (): Product[] => {
  return products.filter(product => product.label === 'New');
};

export const getSaleProducts = (): Product[] => {
  return products.filter(product => product.label === 'Sale' || product.originalPrice);
};
