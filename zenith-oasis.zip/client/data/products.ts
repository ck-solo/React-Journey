export interface Product {
  id: string;
  name: string;
  price: number;
  originalPrice?: number;
  category: 'lipsticks' | 'skincare' | 'accessories';
  image: string;
  images: string[];
  description: string;
  labels: ('new' | 'sold-out' | 'low-stock' | 'bestseller')[];
  stock: number;
  featured?: boolean;
  shades?: { name: string; color: string }[];
}

export interface ProductCollection {
  id: string;
  name: string;
  description: string;
  image: string;
  category: string;
  featured: boolean;
}

export const productCollections: ProductCollection[] = [
  {
    id: 'lipsticks',
    name: 'Lip Collection',
    description: 'Our signature lip products for every mood',
    image: 'https://images.unsplash.com/photo-1586495777744-4413f21062fa?auto=format&fit=crop&w=800&q=80',
    category: 'lipsticks',
    featured: true,
  },
  {
    id: 'skincare',
    name: 'Skincare Essentials',
    description: 'Nourish and glow with our skincare line',
    image: 'https://images.unsplash.com/photo-1570194065650-d99fb4bedf0a?auto=format&fit=crop&w=800&q=80',
    category: 'skincare',
    featured: true,
  },
  {
    id: 'accessories',
    name: 'Beauty Tools',
    description: 'Professional tools for flawless application',
    image: 'https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&w=800&q=80',
    category: 'accessories',
    featured: true,
  },
];

export const products: Product[] = [
  {
    id: 'peach-mango-lip-butter',
    name: 'Peach Mango Lip Butter',
    price: 18,
    category: 'lipsticks',
    image: 'https://images.unsplash.com/photo-1631214542539-ef5a9e1a1c99?auto=format&fit=crop&w=800&q=80',
    images: [
      'https://images.unsplash.com/photo-1631214542539-ef5a9e1a1c99?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1596755389378-c31d21fd1273?auto=format&fit=crop&w=800&q=80',
    ],
    description: 'Luxurious lip butter with a hint of peach and mango. Nourishes and hydrates for soft, kissable lips.',
    labels: ['new', 'bestseller'],
    stock: 45,
    featured: true,
    shades: [
      { name: 'Peach Dream', color: '#FFB5A7' },
      { name: 'Mango Bliss', color: '#FFA07A' },
    ],
  },
  {
    id: 'velvet-matte-lipstick',
    name: 'Velvet Matte Lipstick',
    price: 22,
    category: 'lipsticks',
    image: 'https://images.unsplash.com/photo-1586495777744-4413f21062fa?auto=format&fit=crop&w=800&q=80',
    images: [
      'https://images.unsplash.com/photo-1586495777744-4413f21062fa?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1605721911519-3dfeb3be25e7?auto=format&fit=crop&w=800&q=80',
    ],
    description: 'Long-wearing matte lipstick with a velvet finish. Available in 12 stunning shades.',
    labels: ['bestseller'],
    stock: 32,
    featured: true,
    shades: [
      { name: 'Rose Nude', color: '#C7A299' },
      { name: 'Berry Bold', color: '#8B4B6B' },
      { name: 'Coral Kiss', color: '#FF6B6B' },
    ],
  },
  {
    id: 'glossy-lip-oil',
    name: 'Nourishing Lip Oil',
    price: 16,
    category: 'lipsticks',
    image: 'https://images.unsplash.com/photo-1596755389378-c31d21fd1273?auto=format&fit=crop&w=800&q=80',
    images: [
      'https://images.unsplash.com/photo-1596755389378-c31d21fd1273?auto=format&fit=crop&w=800&q=80',
    ],
    description: 'Lightweight lip oil that provides intense hydration and a natural glossy finish.',
    labels: ['new'],
    stock: 3,
    featured: false,
    shades: [
      { name: 'Clear Shine', color: 'transparent' },
      { name: 'Rose Tint', color: '#FFB5C5' },
    ],
  },
  {
    id: 'vitamin-c-serum',
    name: 'Vitamin C Brightening Serum',
    price: 45,
    category: 'skincare',
    image: 'https://images.unsplash.com/photo-1570194065650-d99fb4bedf0a?auto=format&fit=crop&w=800&q=80',
    images: [
      'https://images.unsplash.com/photo-1570194065650-d99fb4bedf0a?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1598300042247-d088f8ab3a91?auto=format&fit=crop&w=800&q=80',
    ],
    description: 'Powerful vitamin C serum that brightens skin and reduces dark spots for a radiant complexion.',
    labels: ['bestseller'],
    stock: 28,
    featured: true,
  },
  {
    id: 'hydrating-face-mask',
    name: 'Hydrating Rose Face Mask',
    price: 32,
    category: 'skincare',
    image: 'https://images.unsplash.com/photo-1598300042247-d088f8ab3a91?auto=format&fit=crop&w=800&q=80',
    images: [
      'https://images.unsplash.com/photo-1598300042247-d088f8ab3a91?auto=format&fit=crop&w=800&q=80',
    ],
    description: 'Luxurious rose-infused face mask that deeply hydrates and soothes sensitive skin.',
    labels: ['new'],
    stock: 15,
    featured: false,
  },
  {
    id: 'gentle-cleanser',
    name: 'Gentle Foam Cleanser',
    price: 24,
    category: 'skincare',
    image: 'https://images.unsplash.com/photo-1556228578-8c89e6adf883?auto=format&fit=crop&w=800&q=80',
    images: [
      'https://images.unsplash.com/photo-1556228578-8c89e6adf883?auto=format&fit=crop&w=800&q=80',
    ],
    description: 'Gentle daily cleanser that removes makeup and impurities without stripping the skin.',
    labels: [],
    stock: 0,
    featured: false,
  },
  {
    id: 'makeup-brush-set',
    name: 'Professional Brush Set',
    price: 68,
    originalPrice: 85,
    category: 'accessories',
    image: 'https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&w=800&q=80',
    images: [
      'https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1583241800445-8a8b0c3f8592?auto=format&fit=crop&w=800&q=80',
    ],
    description: 'Complete set of professional makeup brushes for face and eyes. Perfect for creating any look.',
    labels: [],
    stock: 12,
    featured: true,
  },
  {
    id: 'beauty-sponge',
    name: 'Beauty Blending Sponge',
    price: 12,
    category: 'accessories',
    image: 'https://images.unsplash.com/photo-1583241800445-8a8b0c3f8592?auto=format&fit=crop&w=800&q=80',
    images: [
      'https://images.unsplash.com/photo-1583241800445-8a8b0c3f8592?auto=format&fit=crop&w=800&q=80',
    ],
    description: 'Ultra-soft beauty sponge for flawless foundation application. Expands when damp.',
    labels: [],
    stock: 8,
    featured: false,
  },
];

export const featuredProducts = products.filter(product => product.featured);
export const newProducts = products.filter(product => product.labels.includes('new'));
export const bestsellers = products.filter(product => product.labels.includes('bestseller'));

export const getProductsByCategory = (category: string) => {
  return products.filter(product => product.category === category);
};

export const getProductById = (id: string) => {
  return products.find(product => product.id === id);
};
