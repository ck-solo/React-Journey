import { Link } from 'react-router-dom';
import { Heart, ShoppingBag } from 'lucide-react';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import type { Product } from '../data/products';

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  const isOnSale = product.originalPrice && product.originalPrice > product.price;
  const isOutOfStock = product.stock === 0;
  const isLowStock = product.stock > 0 && product.stock <= 5;

  const getBadgeVariant = (label: string) => {
    switch (label) {
      case 'new':
        return 'bg-rose-500 text-white';
      case 'bestseller':
        return 'bg-peach-500 text-white';
      case 'sold-out':
        return 'bg-gray-500 text-white';
      case 'low-stock':
        return 'bg-blush-500 text-white';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const formatLabel = (label: string) => {
    switch (label) {
      case 'new':
        return 'New';
      case 'bestseller':
        return 'Bestseller';
      case 'sold-out':
        return 'Sold Out';
      case 'low-stock':
        return `Only ${product.stock} left!`;
      default:
        return label;
    }
  };

  return (
    <Card className="group cursor-pointer border-0 shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden">
      <div className="relative">
        <Link to={`/products/${product.id}`}>
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
          />
        </Link>
        
        {/* Badges */}
        <div className="absolute top-3 left-3 flex flex-col gap-2">
          {isOutOfStock && (
            <Badge className="bg-gray-500 text-white">
              Sold Out
            </Badge>
          )}
          {isLowStock && !isOutOfStock && (
            <Badge className="bg-blush-500 text-white">
              Only {product.stock} left!
            </Badge>
          )}
          {product.labels.map((label) => (
            <Badge key={label} className={getBadgeVariant(label)}>
              {formatLabel(label)}
            </Badge>
          ))}
          {isOnSale && (
            <Badge className="bg-red-500 text-white">
              Sale
            </Badge>
          )}
        </div>

        {/* Action buttons */}
        <div className="absolute top-3 right-3 flex flex-col gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
          <Button 
            size="sm" 
            variant="secondary"
            className="bg-white/90 hover:bg-white shadow-md"
          >
            <Heart className="w-4 h-4" />
          </Button>
          {!isOutOfStock && (
            <Button 
              size="sm" 
              variant="secondary"
              className="bg-white/90 hover:bg-white shadow-md"
            >
              <ShoppingBag className="w-4 h-4" />
            </Button>
          )}
        </div>

        {/* Shade swatches */}
        {product.shades && product.shades.length > 0 && (
          <div className="absolute bottom-3 left-3 flex space-x-1">
            {product.shades.slice(0, 4).map((shade, index) => (
              <div
                key={index}
                className="w-5 h-5 rounded-full border-2 border-white shadow-sm"
                style={{ backgroundColor: shade.color }}
                title={shade.name}
              />
            ))}
            {product.shades.length > 4 && (
              <div className="w-5 h-5 rounded-full border-2 border-white shadow-sm bg-gray-300 flex items-center justify-center">
                <span className="text-xs text-gray-600">+{product.shades.length - 4}</span>
              </div>
            )}
          </div>
        )}
      </div>

      <CardContent className="p-4">
        <Link to={`/products/${product.id}`}>
          <h3 className="font-medium text-gray-900 group-hover:text-rose-600 transition-colors">
            {product.name}
          </h3>
        </Link>
        
        <div className="mt-2 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <span className="text-lg font-semibold text-gray-900">
              ${product.price}
            </span>
            {isOnSale && (
              <span className="text-sm text-gray-500 line-through">
                ${product.originalPrice}
              </span>
            )}
          </div>
          
          {!isOutOfStock && (
            <Button 
              size="sm" 
              className="bg-rose-600 hover:bg-rose-700 text-white"
            >
              Add to Cart
            </Button>
          )}
        </div>

        <p className="mt-2 text-sm text-gray-600 line-clamp-2">
          {product.description}
        </p>
      </CardContent>
    </Card>
  );
}
