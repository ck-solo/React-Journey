import { Link } from 'react-router-dom';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { featuredProducts } from '../data/products';

export function HeroSection() {
  const heroProduct = featuredProducts[0]; // Peach Mango Lip Butter

  return (
    <section id="hero" className="relative bg-gradient-to-br from-rose-50 to-peach-50 overflow-hidden">
      <div className="max-w-7xl mx-auto">
        <div className="relative z-10 pb-8 sm:pb-16 md:pb-20 lg:pb-28 xl:pb-32">
          <main className="mt-10 mx-auto max-w-7xl px-4 sm:mt-12 sm:px-6 md:mt-16 lg:mt-20 lg:px-8 xl:mt-28">
            <div className="lg:grid lg:grid-cols-12 lg:gap-8 items-center">
              <div className="sm:text-center md:max-w-2xl md:mx-auto lg:col-span-6 lg:text-left">
                <div className="mb-4">
                  <Badge variant="secondary" className="mb-4 bg-rose-100 text-rose-800 border-rose-200">
                    ✨ New Launch
                  </Badge>
                </div>
                <h1 className="text-4xl tracking-tight font-bold text-gray-900 sm:text-5xl md:text-6xl">
                  <span className="block xl:inline font-serif">Meet the</span>{' '}
                  <span className="block text-rose-600 xl:inline font-serif">
                    {heroProduct?.name}
                  </span>
                </h1>
                <p className="mt-3 text-base text-gray-500 sm:mt-5 sm:text-lg sm:max-w-xl sm:mx-auto md:mt-5 md:text-xl lg:mx-0">
                  {heroProduct?.description} Experience the perfect blend of nourishment and luxury.
                </p>
                <div className="mt-5 sm:mt-8 sm:flex sm:justify-center lg:justify-start">
                  <div className="rounded-md shadow">
                    <Link to={`/products/${heroProduct?.id}`}>
                      <Button size="lg" className="w-full bg-rose-600 hover:bg-rose-700">
                        Shop Now • ${heroProduct?.price}
                      </Button>
                    </Link>
                  </div>
                  <div className="mt-3 sm:mt-0 sm:ml-3">
                    <Button variant="outline" size="lg" className="w-full border-rose-300 text-rose-600 hover:bg-rose-50">
                      Learn More
                    </Button>
                  </div>
                </div>
                <div className="mt-6 flex items-center space-x-4 text-sm text-gray-500">
                  <div className="flex items-center">
                    <span className="font-medium text-gray-900">Free shipping</span> on orders $50+
                  </div>
                  <div className="flex items-center">
                    <span className="font-medium text-gray-900">30-day</span> return policy
                  </div>
                </div>
              </div>
              <div className="mt-12 relative sm:max-w-lg sm:mx-auto lg:mt-0 lg:max-w-none lg:mx-0 lg:col-span-6 lg:flex lg:items-center">
                <div className="relative mx-auto w-full rounded-lg shadow-lg lg:max-w-md">
                  <div className="relative block w-full bg-white rounded-lg overflow-hidden">
                    <img
                      className="w-full h-96 object-cover"
                      src={heroProduct?.image}
                      alt={heroProduct?.name}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent" />
                    
                    {/* Floating elements */}
                    <div className="absolute top-4 right-4">
                      <Badge className="bg-rose-500 text-white">
                        Bestseller
                      </Badge>
                    </div>
                    
                    {/* Product info overlay */}
                    <div className="absolute bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-white to-transparent">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="text-lg font-semibold text-gray-900">
                            {heroProduct?.name}
                          </h3>
                          <p className="text-rose-600 font-medium">
                            ${heroProduct?.price}
                          </p>
                        </div>
                        <div className="flex space-x-1">
                          {heroProduct?.shades?.slice(0, 3).map((shade, index) => (
                            <div
                              key={index}
                              className="w-6 h-6 rounded-full border-2 border-white shadow-sm"
                              style={{ backgroundColor: shade.color }}
                              title={shade.name}
                            />
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* Decorative elements */}
                <div className="absolute -top-10 -right-10 w-20 h-20 bg-peach-200 rounded-full opacity-60 animate-pulse" />
                <div className="absolute -bottom-6 -left-6 w-16 h-16 bg-rose-200 rounded-full opacity-40 animate-pulse" />
              </div>
            </div>
          </main>
        </div>
      </div>
    </section>
  );
}
