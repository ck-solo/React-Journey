import { Link } from 'react-router-dom';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { productCollections } from '../data/products';

export function ProductCollections() {
  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-gray-900 sm:text-4xl font-serif">
            Shop by Collection
          </h2>
          <p className="mt-4 text-lg text-gray-600 max-w-2xl mx-auto">
            Discover our curated collections designed to enhance your natural beauty
          </p>
        </div>

        <div className="mt-12 grid gap-8 md:grid-cols-3">
          {productCollections.map((collection) => (
            <Card 
              key={collection.id} 
              className="group cursor-pointer border-0 shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden"
            >
              <div className="relative">
                <img
                  src={collection.image}
                  alt={collection.name}
                  className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
                  <h3 className="text-xl font-semibold mb-2 font-serif">
                    {collection.name}
                  </h3>
                  <p className="text-sm text-gray-200 mb-4">
                    {collection.description}
                  </p>
                  <Link to="/products" state={{ category: collection.category }}>
                    <Button 
                      variant="secondary" 
                      size="sm"
                      className="bg-white/90 text-gray-900 hover:bg-white"
                    >
                      View All
                    </Button>
                  </Link>
                </div>
              </div>
            </Card>
          ))}
        </div>

        {/* Categories with smooth scroll */}
        <div className="mt-16 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          <div id="lipsticks" className="text-center p-6 bg-rose-50 rounded-lg">
            <div className="w-16 h-16 bg-rose-200 rounded-full mx-auto mb-4 flex items-center justify-center">
              💋
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">Lipsticks</h3>
            <p className="text-sm text-gray-600">Bold, beautiful, and long-lasting</p>
          </div>

          <div id="skincare" className="text-center p-6 bg-peach-50 rounded-lg">
            <div className="w-16 h-16 bg-peach-200 rounded-full mx-auto mb-4 flex items-center justify-center">
              ✨
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">Skincare</h3>
            <p className="text-sm text-gray-600">Nourish and protect your skin</p>
          </div>

          <div id="sale" className="text-center p-6 bg-blush-50 rounded-lg">
            <div className="w-16 h-16 bg-blush-200 rounded-full mx-auto mb-4 flex items-center justify-center">
              🏷️
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">Sale</h3>
            <p className="text-sm text-gray-600">Limited time offers</p>
          </div>

          <div id="accessories" className="text-center p-6 bg-nude-50 rounded-lg">
            <div className="w-16 h-16 bg-nude-200 rounded-full mx-auto mb-4 flex items-center justify-center">
              🖌️
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">Accessories</h3>
            <p className="text-sm text-gray-600">Professional tools and more</p>
          </div>
        </div>
      </div>
    </section>
  );
}
