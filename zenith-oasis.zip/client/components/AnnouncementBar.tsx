import { X } from 'lucide-react';
import { useState } from 'react';

export function AnnouncementBar() {
  const [isVisible, setIsVisible] = useState(true);

  if (!isVisible) return null;

  return (
    <div className="bg-rose-500 text-white text-sm py-2 px-4 relative">
      <div className="container mx-auto flex items-center justify-center">
        <p className="text-center">
          ✨ Free shipping on orders over $50 • Limited edition just dropped!
        </p>
        <button
          onClick={() => setIsVisible(false)}
          className="absolute right-4 hover:bg-rose-600 p-1 rounded"
          aria-label="Close announcement"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
