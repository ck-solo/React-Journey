import { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Heart, ShoppingBag, Star, ChevronLeft, Minus, Plus } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { Card, CardContent } from '../components/ui/card';
import { getProductById, products } from '../data/products';

export function ProductDetail() {
  const { id } = useParams<{ id: string }>();
  const product = id ? getProductById(id) : null;
  const [selectedImage, setSelectedImage] = useState(0);
  const [selectedShade, setSelectedShade] = useState(0);
  const [quantity, setQuantity] = useState(1);

  if (!product) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Product Not Found</h2>
          <p className="text-gray-600 mb-6">The product you're looking for doesn't exist.</p>
          <Link to="/products">
            <Button>Browse All Products</Button>
          </Link>
        </div>
      </div>
    );
  }

  const isOutOfStock = product.stock === 0;
  const isLowStock = product.stock > 0 && product.stock <= 5;
  const isOnSale = product.originalPrice && product.originalPrice > product.price;

  const relatedProducts = products
    .filter(p => p.category === product.category && p.id !== product.id)
    .slice(0, 4);

  return (
    <div className="min-h-screen bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Breadcrumb */}
        <nav className="flex items-center space-x-2 text-sm text-gray-500 mb-8">
          <Link to="/" className="hover:text-gray-700">Home</Link>
          <span>/</span>
          <Link to="/products" className="hover:text-gray-700">Products</Link>
          <span>/</span>
          <span className="text-gray-900 capitalize">{product.category}</span>
          <span>/</span>
          <span className="text-gray-900">{product.name}</span>
        </nav>

        <div className="lg:grid lg:grid-cols-2 lg:gap-x-8 lg:items-start">
          {/* Product Images */}
          <div className="flex flex-col-reverse">
            {/* Image thumbnails */}
            <div className="hidden mt-6 w-full max-w-2xl mx-auto sm:block lg:max-w-none">
              <div className="grid grid-cols-4 gap-6">
                {product.images.map((image, index) => (
                  <button
                    key={index}
                    onClick={() => setSelectedImage(index)}
                    className={`relative h-24 bg-white rounded-md flex items-center justify-center text-sm font-medium uppercase text-gray-900 cursor-pointer hover:bg-gray-50 focus:outline-none focus:ring focus:ring-offset-4 focus:ring-rose-500 ${
                      selectedImage === index ? 'ring-2 ring-rose-500' : ''
                    }`}
                  >
                    <img
                      src={image}
                      alt={`${product.name} ${index + 1}`}
                      className="w-full h-full object-cover rounded-md"
                    />
                  </button>
                ))}
              </div>
            </div>

            {/* Main image */}
            <div className="w-full aspect-square">
              <img
                src={product.images[selectedImage]}
                alt={product.name}
                className="w-full h-full object-cover object-center sm:rounded-lg"
              />
            </div>
          </div>

          {/* Product info */}
          <div className="mt-10 px-4 sm:px-0 sm:mt-16 lg:mt-0">
            <Link to="/products" className="inline-flex items-center text-sm text-gray-500 hover:text-gray-700 mb-4">
              <ChevronLeft className="w-4 h-4 mr-1" />
              Back to Products
            </Link>

            <h1 className="text-3xl font-bold tracking-tight text-gray-900 font-serif">
              {product.name}
            </h1>

            {/* Price */}
            <div className="mt-3">
              <div className="flex items-center space-x-3">
                <p className="text-3xl font-bold text-gray-900">${product.price}</p>
                {isOnSale && (
                  <p className="text-xl text-gray-500 line-through">${product.originalPrice}</p>
                )}
              </div>
            </div>

            {/* Reviews */}
            <div className="mt-3">
              <div className="flex items-center">
                <div className="flex items-center">
                  {[0, 1, 2, 3, 4].map((rating) => (
                    <Star
                      key={rating}
                      className="h-5 w-5 text-yellow-400 fill-current"
                      aria-hidden="true"
                    />
                  ))}
                </div>
                <p className="ml-3 text-sm text-gray-500">
                  4.8 out of 5 stars (124 reviews)
                </p>
              </div>
            </div>

            {/* Badges */}
            <div className="mt-4 flex flex-wrap gap-2">
              {product.labels.map((label) => (
                <Badge key={label} variant="secondary">
                  {label === 'new' ? 'New' : label === 'bestseller' ? 'Bestseller' : label}
                </Badge>
              ))}
              {isOnSale && <Badge className="bg-red-500 text-white">Sale</Badge>}
            </div>

            {/* Description */}
            <div className="mt-6">
              <h3 className="sr-only">Description</h3>
              <p className="text-base text-gray-700">{product.description}</p>
            </div>

            {/* Shade selection */}
            {product.shades && product.shades.length > 0 && (
              <div className="mt-6">
                <h3 className="text-sm font-medium text-gray-900">
                  Shade: {product.shades[selectedShade]?.name}
                </h3>
                <div className="mt-2 flex space-x-3">
                  {product.shades.map((shade, index) => (
                    <button
                      key={index}
                      onClick={() => setSelectedShade(index)}
                      className={`relative w-8 h-8 rounded-full border-2 ${
                        selectedShade === index ? 'border-rose-500' : 'border-gray-300'
                      }`}
                      style={{ backgroundColor: shade.color }}
                      title={shade.name}
                    >
                      {selectedShade === index && (
                        <div className="absolute inset-0 rounded-full ring-2 ring-rose-500 ring-offset-2" />
                      )}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Stock status */}
            <div className="mt-6">
              {isOutOfStock ? (
                <Badge variant="destructive">Out of Stock</Badge>
              ) : isLowStock ? (
                <Badge className="bg-orange-500 text-white">
                  Only {product.stock} left in stock!
                </Badge>
              ) : (
                <Badge className="bg-green-500 text-white">In Stock</Badge>
              )}
            </div>

            {/* Quantity and Add to cart */}
            <div className="mt-8">
              <div className="flex items-center space-x-4 mb-4">
                <label htmlFor="quantity" className="text-sm font-medium text-gray-900">
                  Quantity:
                </label>
                <div className="flex items-center border rounded-md">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="p-2 hover:bg-gray-100"
                    disabled={quantity <= 1}
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  <span className="px-4 py-2 text-center min-w-16">{quantity}</span>
                  <button
                    onClick={() => setQuantity(Math.min(product.stock, quantity + 1))}
                    className="p-2 hover:bg-gray-100"
                    disabled={quantity >= product.stock || isOutOfStock}
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <Button
                  size="lg"
                  className="flex-1 bg-rose-600 hover:bg-rose-700"
                  disabled={isOutOfStock}
                >
                  <ShoppingBag className="w-5 h-5 mr-2" />
                  {isOutOfStock ? 'Out of Stock' : 'Add to Cart'}
                </Button>
                <Button variant="outline" size="lg" className="border-rose-300 text-rose-600 hover:bg-rose-50">
                  <Heart className="w-5 h-5 mr-2" />
                  Add to Wishlist
                </Button>
              </div>

              {!isOutOfStock && (
                <Button variant="link" size="lg" className="w-full mt-2 text-rose-600">
                  Buy Now
                </Button>
              )}
            </div>

            {/* Product features */}
            <div className="mt-8 border-t border-gray-200 pt-8">
              <h3 className="text-sm font-medium text-gray-900">Features</h3>
              <ul className="mt-4 space-y-2 text-sm text-gray-600">
                <li>• Cruelty-free and vegan</li>
                <li>• Long-lasting formula</li>
                <li>• Suitable for all skin types</li>
                <li>• Free shipping on orders over $50</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Related products */}
        {relatedProducts.length > 0 && (
          <div className="mt-16">
            <h2 className="text-2xl font-bold text-gray-900 mb-8 font-serif">
              You might also like
            </h2>
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
              {relatedProducts.map((relatedProduct) => (
                <Card key={relatedProduct.id} className="group cursor-pointer">
                  <Link to={`/products/${relatedProduct.id}`}>
                    <img
                      src={relatedProduct.image}
                      alt={relatedProduct.name}
                      className="w-full h-48 object-cover rounded-t-lg group-hover:opacity-75 transition-opacity"
                    />
                  </Link>
                  <CardContent className="p-4">
                    <Link to={`/products/${relatedProduct.id}`}>
                      <h3 className="text-sm font-medium text-gray-900 group-hover:text-rose-600">
                        {relatedProduct.name}
                      </h3>
                    </Link>
                    <p className="mt-1 text-lg font-semibold text-gray-900">
                      ${relatedProduct.price}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
