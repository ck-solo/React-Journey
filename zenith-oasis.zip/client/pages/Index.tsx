import { HeroSection } from '../components/HeroSection';
import { ProductCollections } from '../components/ProductCollections';
import { FeaturedProducts } from '../components/FeaturedProducts';

export default function Index() {
  return (
    <div className="min-h-screen">
      <HeroSection />
      <ProductCollections />
      <FeaturedProducts />
    </div>
  );
}
